"""
ADNI Visualization Module
=========================
Creates publication-quality visualizations for EDA results.
"""

import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend

import seaborn as sns
import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple
from pathlib import Path

from config.settings import COLORS, FIGURE_DPI, FIGURE_FORMAT, FIGURE_SIZE

# Set default style
sns.set_style('whitegrid')
plt.rcParams['figure.dpi'] = FIGURE_DPI
plt.rcParams['savefig.dpi'] = FIGURE_DPI


class ADNIVisualizer:
    """
    Creates visualizations for ADNI EDA results.
    """
    
    def __init__(self, output_dir: Optional[Path] = None):
        """
        Initialize visualizer.
        
        Parameters
        ----------
        output_dir : Path, optional
            Directory to save visualizations.
        """
        from config.settings import VISUALIZATIONS_DIR
        self.output_dir = output_dir or VISUALIZATIONS_DIR
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def save_figure(self, fig: plt.Figure, filename: str):
        """
        Save figure to output directory.
        
        Parameters
        ----------
        fig : plt.Figure
            Figure to save.
        filename : str
            Output filename.
        """
        filepath = self.output_dir / filename
        fig.savefig(filepath, bbox_inches='tight', format=FIGURE_FORMAT)
        plt.close(fig)
        print(f"Saved: {filename}")
    
    def plot_dataset_overview(self, summary_df: pd.DataFrame, filename: str = '01_dataset_overview.png'):
        """
        Plot dataset overview by category.
        
        Parameters
        ----------
        summary_df : pd.DataFrame
            Dataset summary table.
        filename : str
            Output filename.
        """
        fig, ax = plt.subplots(figsize=FIGURE_SIZE)
        
        categories = summary_df.groupby('Category')['Rows'].sum().sort_values(ascending=True)
        colors = [COLORS['primary'], COLORS['secondary'], COLORS['tertiary']]
        
        bars = ax.barh(categories.index, categories.values, color=colors[:len(categories)])
        ax.set_xlabel('Total Records', fontsize=12)
        ax.set_title('ADNI Dataset Overview by Category', fontsize=14, fontweight='bold')
        ax.set_xlim(0, max(categories.values) * 1.1)
        
        for bar, val in zip(bars, categories.values):
            ax.text(val + max(categories.values) * 0.02, bar.get_y() + bar.get_height()/2, 
                   f'{val:,}', va='center', fontsize=10)
        
        sns.despine()
        self.save_figure(fig, filename)
    
    def plot_missing_data(self, schema_info: Dict[str, Dict], 
                          filename: str = '02_missing_data.png'):
        """
        Plot missing data by dataset.
        
        Parameters
        ----------
        schema_info : Dict[str, Dict]
            Schema analysis results.
        filename : str
            Output filename.
        """
        fig, ax = plt.subplots(figsize=(14, 10))
        
        # Sort by missing percentage
        sorted_info = sorted(schema_info.items(), 
                            key=lambda x: x[1]['missing_pct'], 
                            reverse=True)[:15]
        
        dataset_names = [name[:25] for name, _ in sorted_info]
        missing_pcts = [info['missing_pct'] for _, info in sorted_info]
        
        # Color by severity
        colors = []
        for pct in missing_pcts:
            if pct < 10:
                colors.append(COLORS['success'])
            elif pct < 30:
                colors.append(COLORS['warning'])
            else:
                colors.append(COLORS['danger'])
        
        bars = ax.barh(dataset_names, missing_pcts, color=colors)
        ax.set_xlabel('Missing Data (%)', fontsize=12)
        ax.set_title('Missing Data by Dataset (Top 15)', fontsize=14, fontweight='bold')
        ax.axvline(x=10, color='gray', linestyle='--', alpha=0.5)
        ax.axvline(x=30, color='gray', linestyle='--', alpha=0.5)
        
        for bar, val in zip(bars, missing_pcts):
            ax.text(val + 1, bar.get_y() + bar.get_height()/2, 
                   f'{val:.1f}%', va='center', fontsize=9)
        
        sns.despine()
        self.save_figure(fig, filename)
    
    def plot_biomarker_distributions(self, df: pd.DataFrame, 
                                      filename: str = '03_biomarker_distributions.png'):
        """
        Plot distributions of key biomarkers and cognitive scores.
        
        Parameters
        ----------
        df : pd.DataFrame
            Biomarker dataset.
        filename : str
            Output filename.
        """
        from config.settings import BIOMARKER_COLUMNS, COGNITIVE_COLUMNS
        
        fig, axes = plt.subplots(2, 3, figsize=(15, 10))
        axes = axes.flatten()
        
        biomarkers = [
            ('pT217_F', 'p-tau217 (pg/mL)', df),
            ('AB42_AB40_F', 'Aβ42/40 Ratio', df),
            ('NfL_Q', 'NfL (pg/mL)', df),
            ('GFAP_Q', 'GFAP (pg/mL)', df),
        ]
        
        # Add cognitive if available
        for col, title in COGNITIVE_COLUMNS.items():
            if col in df.columns:
                biomarkers.append((col, title, df))
        
        for i, (col, title, data_df) in enumerate(biomarkers[:6]):
            if col not in data_df.columns:
                continue
                
            data = data_df[col].dropna()
            data = data[data >= 0]
            
            # Remove extreme outliers for visualization
            q99 = data.quantile(0.99)
            data = data[data <= q99]
            
            axes[i].hist(data, bins=50, color=COLORS['primary'], 
                        edgecolor='white', alpha=0.7)
            axes[i].set_title(title, fontsize=12, fontweight='bold')
            axes[i].set_xlabel('Value')
            axes[i].set_ylabel('Frequency')
            axes[i].axvline(data.median(), color='red', linestyle='--', 
                           linewidth=2, label=f'Median: {data.median():.2f}')
            axes[i].legend()
        
        plt.suptitle('Distribution of Key Biomarkers and Cognitive Scores', 
                    fontsize=14, fontweight='bold', y=1.02)
        plt.tight_layout()
        self.save_figure(fig, filename)
    
    def plot_correlation_heatmap(self, corr_matrix: pd.DataFrame, 
                                  filename: str = '04_correlation_heatmap.png'):
        """
        Plot correlation heatmap.
        
        Parameters
        ----------
        corr_matrix : pd.DataFrame
            Correlation matrix.
        filename : str
            Output filename.
        """
        fig, ax = plt.subplots(figsize=(10, 8))
        
        im = ax.imshow(corr_matrix, cmap='RdBu_r', vmin=-1, vmax=1)
        
        ax.set_xticks(range(len(corr_matrix.columns)))
        ax.set_yticks(range(len(corr_matrix.columns)))
        ax.set_xticklabels(corr_matrix.columns, rotation=45, ha='right')
        ax.set_yticklabels(corr_matrix.columns)
        ax.set_title('Multimodal Correlation Matrix', fontsize=14, fontweight='bold')
        
        # Add correlation values
        for i in range(len(corr_matrix.columns)):
            for j in range(len(corr_matrix.columns)):
                val = corr_matrix.iloc[i, j]
                if not np.isnan(val):
                    text_color = 'white' if abs(val) > 0.5 else 'black'
                    ax.text(j, i, f'{val:.2f}', ha='center', va='center', 
                           fontsize=10, color=text_color)
        
        plt.colorbar(im, ax=ax, label='Pearson r')
        plt.tight_layout()
        self.save_figure(fig, filename)
    
    def plot_study_phases(self, phase_distribution: pd.DataFrame, 
                          filename: str = '05_study_phases.png'):
        """
        Plot study phase distribution.
        
        Parameters
        ----------
        phase_distribution : pd.DataFrame
            Phase distribution data.
        filename : str
            Output filename.
        """
        fig, ax = plt.subplots(figsize=(10, 6))
        
        colors = [COLORS['primary'], COLORS['secondary'], COLORS['tertiary'], 
                 COLORS['warning'], COLORS['info']]
        
        wedges, texts, autotexts = ax.pie(
            phase_distribution['Count'], 
            labels=phase_distribution['Phase'], 
            autopct='%1.1f%%',
            colors=colors[:len(phase_distribution)],
            startangle=90
        )
        
        ax.set_title('Study Phase Distribution', fontsize=14, fontweight='bold')
        plt.tight_layout()
        self.save_figure(fig, filename)
    
    def plot_longitudinal_patterns(self, visit_summaries: Dict[str, Dict], 
                                    filename: str = '06_longitudinal_patterns.png'):
        """
        Plot longitudinal visit patterns.
        
        Parameters
        ----------
        visit_summaries : Dict[str, Dict]
            Visit pattern summaries.
        filename : str
            Output filename.
        """
        fig, axes = plt.subplots(1, 3, figsize=(15, 5))
        
        for i, (name, summary) in enumerate(list(visit_summaries.items())[:3]):
            if 'error' in summary:
                continue
            
            # Get visit counts (would need actual data for full distribution)
            mean_visits = summary['mean_visits_per_participant']
            max_visits = summary['max_visits']
            
            # Create simple bar chart of key metrics
            metrics = ['Mean', 'Max']
            values = [mean_visits, max_visits]
            
            axes[i].bar(metrics, values, color=COLORS['primary'], edgecolor='white')
            axes[i].set_ylabel('Visits')
            axes[i].set_title(f"{name[:15]}...\n(Mean: {mean_visits:.1f})", 
                            fontsize=12, fontweight='bold')
        
        plt.suptitle('Longitudinal Visit Patterns', fontsize=14, fontweight='bold')
        plt.tight_layout()
        self.save_figure(fig, filename)
    
    def plot_cdr_distribution(self, cdr_distribution: Dict, 
                               filename: str = '07_cdr_distribution.png'):
        """
        Plot CDR Global score distribution.
        
        Parameters
        ----------
        cdr_distribution : Dict
            CDR Global score counts.
        filename : str
            Output filename.
        """
        fig, ax = plt.subplots(figsize=(10, 6))
        
        scores = sorted(cdr_distribution.keys())
        counts = [cdr_distribution[s] for s in scores]
        total = sum(counts)
        
        colors = [COLORS['success'], COLORS['warning'], COLORS['secondary'], 
                 COLORS['danger'], '#7030A0']
        
        bars = ax.bar([f'CDR {s}' for s in scores], counts, 
                     color=colors[:len(scores)])
        
        ax.set_xlabel('CDR Global Score')
        ax.set_ylabel('Number of Assessments')
        ax.set_title('CDR Global Score Distribution (Target Variable)', 
                    fontsize=14, fontweight='bold')
        
        for bar, val in zip(bars, counts):
            ax.text(bar.get_x() + bar.get_width()/2, val + max(counts) * 0.01, 
                   f'{val:,}\n({val/total*100:.1f}%)', 
                   ha='center', va='bottom', fontsize=10)
        
        sns.despine()
        self.save_figure(fig, filename)
    
    def create_all_visualizations(self, datasets: Dict[str, Dict], 
                                   schema_info: Dict[str, Dict],
                                   summary_df: pd.DataFrame):
        """
        Create all standard visualizations.
        
        Parameters
        ----------
        datasets : Dict[str, Dict]
            Loaded datasets.
        schema_info : Dict[str, Dict]
            Schema analysis results.
        summary_df : pd.DataFrame
            Dataset summary table.
        """
        print("Creating visualizations...\n")
        
        # 1. Dataset overview
        self.plot_dataset_overview(summary_df)
        
        # 2. Missing data
        self.plot_missing_data(schema_info)
        
        # 3. Biomarker distributions
        if 'UPENN_PLASMA_FUJIREBIO_QUANTERIX_13Feb2026' in datasets:
            upenn_df = datasets['UPENN_PLASMA_FUJIREBIO_QUANTERIX_13Feb2026']['df']
            self.plot_biomarker_distributions(upenn_df)
        
        # 4. Correlation heatmap (will need to be generated from analysis)
        # Placeholder - actual correlation matrix comes from analysis
        
        # 5. Study phases
        from src.analysis.longitudinal_analyzer import LongitudinalAnalyzer
        long_analyzer = LongitudinalAnalyzer(datasets)
        phase_dist = long_analyzer.get_study_phase_distribution()
        if not phase_dist.empty:
            self.plot_study_phases(phase_dist)
        
        # 6. Longitudinal patterns
        visit_summaries = long_analyzer.analyze_all_datasets()
        self.plot_longitudinal_patterns(visit_summaries)
        
        # 7. CDR distribution
        if 'CDR_13Feb2026' in datasets:
            cdr_df = datasets['CDR_13Feb2026']['df']
            if 'CDGLOBAL' in cdr_df.columns:
                cdr_global = cdr_df['CDGLOBAL'].dropna()
                cdr_global = cdr_global[cdr_global >= 0]
                cdr_dist = cdr_global.value_counts().sort_index().to_dict()
                self.plot_cdr_distribution(cdr_dist)
        
        print(f"\nAll visualizations saved to: {self.output_dir}")


if __name__ == '__main__':
    # Example usage
    from src.data.loader import load_and_preprocess_adni_data
    from src.analysis.schema_analyzer import SchemaAnalyzer
    
    datasets, summary_df = load_and_preprocess_adni_data()
    
    analyzer = SchemaAnalyzer(datasets)
    schema_info = analyzer.analyze_all()
    
    visualizer = ADNIVisualizer()
    visualizer.create_all_visualizations(datasets, schema_info, summary_df)
