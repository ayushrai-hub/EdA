"""
ADNI Schema Analyzer Module
===========================
Analyzes schema structure, relationships, and data quality across ADNI datasets.
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple
from collections import defaultdict

from config.settings import ID_COLUMNS, MISSING_HIGH_THRESHOLD


class SchemaAnalyzer:
    """
    Comprehensive schema analysis for ADNI datasets including:
    - Key identifier detection
    - Missing data analysis
    - Relationship mapping
    - Data quality assessment
    """
    
    def __init__(self, datasets: Dict[str, Dict]):
        """
        Initialize schema analyzer.
        
        Parameters
        ----------
        datasets : Dict[str, Dict]
            Dictionary of loaded datasets from ADNILoader.
        """
        self.datasets = datasets
        self.schema_info: Dict[str, Dict] = {}
        
    def analyze_dataset(self, name: str) -> Dict:
        """
        Perform comprehensive schema analysis on a single dataset.
        
        Parameters
        ----------
        name : str
            Dataset name.
            
        Returns
        -------
        Dict
            Schema analysis results.
        """
        if name not in self.datasets:
            raise ValueError(f"Dataset '{name}' not found")
        
        df = self.datasets[name]['df']
        rows, cols = df.shape
        
        # Identify key columns
        key_info = {}
        for key in ID_COLUMNS:
            if key in df.columns:
                non_null = df[key].notna().sum()
                unique = df[key].nunique()
                key_info[key] = {
                    'present': True,
                    'non_null': int(non_null),
                    'unique': int(unique),
                    'coverage': float(non_null / len(df) * 100) if len(df) > 0 else 0
                }
            else:
                key_info[key] = {'present': False}
        
        # Missing data analysis
        missing_counts = df.isnull().sum()
        total_cells = rows * cols
        total_missing = missing_counts.sum()
        missing_pct = (total_missing / total_cells) * 100 if total_cells > 0 else 0
        
        # Sparse columns (>50% missing)
        sparse_cols = missing_counts[missing_counts > rows * MISSING_HIGH_THRESHOLD].index.tolist()
        
        # Duplicate rows
        dup_rows = int(df.duplicated().sum())
        
        # Memory usage
        memory_mb = float(df.memory_usage(deep=True).sum() / (1024 * 1024))
        
        # Date columns
        date_cols = self.datasets[name].get('date_columns', [])
        
        analysis = {
            'name': name,
            'category': self.datasets[name]['category'],
            'rows': rows,
            'columns': cols,
            'memory_mb': round(memory_mb, 2),
            'key_columns': key_info,
            'missing_pct': round(missing_pct, 2),
            'sparse_columns': len(sparse_cols),
            'sparse_column_names': sparse_cols,
            'duplicate_rows': dup_rows,
            'date_columns': date_cols,
        }
        
        self.schema_info[name] = analysis
        return analysis
    
    def analyze_all(self) -> Dict[str, Dict]:
        """
        Analyze all datasets.
        
        Returns
        -------
        Dict[str, Dict]
            Dictionary of schema analyses for all datasets.
        """
        print("Analyzing schema for all datasets...\n")
        
        for name in sorted(self.datasets.keys()):
            self.analyze_dataset(name)
            print(f"✓ Analyzed: {name}")
        
        print(f"\nCompleted schema analysis for {len(self.schema_info)} datasets")
        return self.schema_info
    
    def get_join_analysis(self) -> pd.DataFrame:
        """
        Analyze join key availability across datasets.
        
        Returns
        -------
        pd.DataFrame
            Join key availability matrix.
        """
        if not self.schema_info:
            self.analyze_all()
        
        join_data = []
        for name, info in self.schema_info.items():
            row = {'Dataset': name}
            for key in ID_COLUMNS:
                if key in info['key_columns'] and info['key_columns'][key]['present']:
                    row[key] = info['key_columns'][key]['non_null']
                else:
                    row[key] = '-'
            join_data.append(row)
        
        return pd.DataFrame(join_data)
    
    def find_joinable_datasets(self, keys: List[str]) -> List[str]:
        """
        Find datasets that can be joined on specified keys.
        
        Parameters
        ----------
        keys : List[str]
            List of required join keys (e.g., ['RID', 'VISCODE2']).
            
        Returns
        -------
        List[str]
            List of dataset names that have all specified keys.
        """
        if not self.schema_info:
            self.analyze_all()
        
        joinable = []
        for name, info in self.schema_info.items():
            has_all_keys = all(
                info['key_columns'].get(key, {}).get('present', False)
                for key in keys
            )
            if has_all_keys:
                joinable.append(name)
        
        return joinable
    
    def get_relationship_map(self) -> Dict[str, Dict]:
        """
        Build a relationship map showing how datasets connect.
        
        Returns
        -------
        Dict[str, Dict]
            Relationship mapping between datasets.
        """
        if not self.schema_info:
            self.analyze_all()
        
        relationships = {
            'rid_viscode2': self.find_joinable_datasets(['RID', 'VISCODE2']),
            'rid_viscode': self.find_joinable_datasets(['RID', 'VISCODE']),
            'rid_only': [],
        }
        
        # Find RID-only datasets
        for name, info in self.schema_info.items():
            has_rid = info['key_columns'].get('RID', {}).get('present', False)
            has_viscode = info['key_columns'].get('VISCODE', {}).get('present', False)
            has_viscode2 = info['key_columns'].get('VISCODE2', {}).get('present', False)
            
            if has_rid and not has_viscode and not has_viscode2:
                relationships['rid_only'].append(name)
        
        return relationships
    
    def get_summary_table(self) -> pd.DataFrame:
        """
        Get summary table of all schema analyses.
        
        Returns
        -------
        pd.DataFrame
            Summary table suitable for reporting.
        """
        if not self.schema_info:
            self.analyze_all()
        
        summaries = []
        for name, info in self.schema_info.items():
            summary = {
                'Dataset': name,
                'Category': info['category'],
                'Rows': info['rows'],
                'Columns': info['columns'],
                'Memory_MB': info['memory_mb'],
                'Has_RID': info['key_columns'].get('RID', {}).get('present', False),
                'Has_PTID': info['key_columns'].get('PTID', {}).get('present', False),
                'Has_VISCODE': info['key_columns'].get('VISCODE', {}).get('present', False),
                'Has_VISCODE2': info['key_columns'].get('VISCODE2', {}).get('present', False),
                'Has_PHASE': info['key_columns'].get('PHASE', {}).get('present', False),
                'Unique_RID': info['key_columns'].get('RID', {}).get('unique', 0),
                'Missing_Pct': info['missing_pct'],
                'Sparse_Cols': info['sparse_columns'],
                'Duplicate_Rows': info['duplicate_rows'],
            }
            summaries.append(summary)
        
        df = pd.DataFrame(summaries)
        return df.sort_values(['Category', 'Rows'], ascending=[True, False])
    
    def get_category_aggregates(self) -> pd.DataFrame:
        """
        Get aggregate statistics by category.
        
        Returns
        -------
        pd.DataFrame
            Aggregate statistics table.
        """
        summary = self.get_summary_table()
        
        agg = summary.groupby('Category').agg({
            'Dataset': 'count',
            'Rows': 'sum',
            'Columns': 'mean',
            'Memory_MB': 'sum',
            'Unique_RID': 'sum',
            'Missing_Pct': 'mean',
            'Sparse_Cols': 'sum',
        }).round(2)
        
        agg.columns = ['Files', 'Total_Rows', 'Avg_Cols', 'Total_Memory_MB', 
                       'Total_Unique_RID', 'Avg_Missing_Pct', 'Total_Sparse_Cols']
        
        return agg
    
    def print_detailed_report(self):
        """Print a detailed schema analysis report to console."""
        if not self.schema_info:
            self.analyze_all()
        
        print("=" * 100)
        print("SCHEMA ANALYSIS REPORT")
        print("=" * 100)
        
        for name, info in sorted(self.schema_info.items()):
            print(f"\n{'─' * 100}")
            print(f"DATASET: {name} | Category: {info['category'].upper()}")
            print(f"{'─' * 100}")
            print(f"  Dimensions:     {info['rows']:,} rows × {info['columns']} columns")
            print(f"  Memory:         {info['memory_mb']:.2f} MB")
            
            # Key columns
            rid_info = info['key_columns'].get('RID', {})
            ptid_info = info['key_columns'].get('PTID', {})
            viscode_info = info['key_columns'].get('VISCODE', {})
            viscode2_info = info['key_columns'].get('VISCODE2', {})
            phase_info = info['key_columns'].get('PHASE', {})
            
            print(f"  Key Columns:    RID={rid_info.get('present', False)}, "
                  f"PTID={ptid_info.get('present', False)}, "
                  f"VISCODE={viscode_info.get('present', False)}, "
                  f"VISCODE2={viscode2_info.get('present', False)}, "
                  f"PHASE={phase_info.get('present', False)}")
            
            if rid_info.get('present'):
                print(f"  Unique IDs:     RID={rid_info.get('unique', 0):,}")
            
            print(f"  Missing Data:   {info['missing_pct']:.2f}%")
            print(f"  Sparse Columns: {info['sparse_columns']} (>50% missing)")
            print(f"  Duplicate Rows: {info['duplicate_rows']:,}")
        
        # Summary table
        print("\n" + "=" * 100)
        print("SUMMARY TABLE")
        print("=" * 100)
        print(self.get_summary_table().to_string(index=False))
        
        # Category aggregates
        print("\n" + "=" * 100)
        print("AGGREGATES BY CATEGORY")
        print("=" * 100)
        print(self.get_category_aggregates().to_string())


if __name__ == '__main__':
    # Example usage
    from src.data.loader import load_and_preprocess_adni_data
    
    datasets, _ = load_and_preprocess_adni_data()
    analyzer = SchemaAnalyzer(datasets)
    analyzer.print_detailed_report()
