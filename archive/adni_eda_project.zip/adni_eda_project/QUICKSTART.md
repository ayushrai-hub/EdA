# ADNI EDA Quick Start Guide

## Installation

```bash
# Install dependencies
pip install -r requirements.txt

# Or install as package
pip install -e .
```

## Quick Start

### 1. Run Full EDA Pipeline

```bash
python run_eda.py --data-dir /path/to/adni/csv/files --output-dir ./output
```

### 2. Use Jupyter Notebook

```bash
jupyter notebook notebooks/ADNI_EDA_Notebook.ipynb
```

### 3. Python API Usage

```python
from src.data.loader import load_and_preprocess_adni_data
from src.analysis.schema_analyzer import SchemaAnalyzer
from src.analysis.statistical_analyzer import StatisticalAnalyzer
from src.analysis.ml_readiness import MLReadinessAnalyzer

# Load data
datasets, summary = load_and_preprocess_adni_data('/path/to/data')

# Run analyses
schema_analyzer = SchemaAnalyzer(datasets)
schema_info = schema_analyzer.analyze_all()

stat_analyzer = StatisticalAnalyzer(datasets)
bio_results = stat_analyzer.analyze_biomarkers()

ml_analyzer = MLReadinessAnalyzer(datasets)
ml_analyzer.print_ml_report()
```

## Key Modules

| Module | Purpose |
|--------|---------|
| `src.data.loader` | Data loading and preprocessing |
| `src.analysis.schema_analyzer` | Schema and relationship analysis |
| `src.analysis.statistical_analyzer` | Statistical EDA |
| `src.analysis.longitudinal_analyzer` | Longitudinal patterns |
| `src.analysis.ml_readiness` | ML readiness assessment |
| `src.visualization.plots` | Visualization generation |

## Configuration

Edit `config/settings.py` to customize:
- Data directory path
- Sentinel missing values
- Output directories
- Visualization settings

## Output Structure

```
output/
├── reports/           # Markdown reports
├── tables/            # CSV data tables
└── visualizations/    # PNG figures
```

## Common Tasks

### Load specific dataset
```python
df = datasets['UPENN_PLASMA_FUJIREBIO_QUANTERIX_13Feb2026']['df']
```

### Get biomarker statistics
```python
bio_stats = stat_analyzer.analyze_biomarkers()
print(bio_stats['descriptive_stats'])
```

### Create integrated dataset
```python
integrated = ml_analyzer.create_integrated_dataset()
```

### Generate visualizations
```python
from src.visualization.plots import ADNIVisualizer
viz = ADNIVisualizer()
viz.plot_dataset_overview(summary_df)
```

## Troubleshooting

**ImportError: No module named 'src'**
- Make sure you're running from the project root directory
- Or add project root to PYTHONPATH: `export PYTHONPATH=$PYTHONPATH:/path/to/adni_eda_project`

**FileNotFoundError: Data files not found**
- Check that `DATA_DIR` in `config/settings.py` points to your ADNI CSV files
- Or pass `--data-dir` argument to `run_eda.py`

**Memory Error**
- The full dataset is ~170MB, ensure you have sufficient RAM
- Process datasets individually if needed
