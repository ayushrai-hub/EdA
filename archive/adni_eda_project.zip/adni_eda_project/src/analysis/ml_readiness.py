"""
ADNI Machine Learning Readiness Assessment Module
=================================================
Assesses data suitability for machine learning models including
feature variance, multicollinearity, and target variable analysis.
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple


class MLReadinessAnalyzer:
    """
    Assesses ML readiness of ADNI data.
    """
    
    def __init__(self, datasets: Dict[str, Dict]):
        """
        Initialize ML readiness analyzer.
        
        Parameters
        ----------
        datasets : Dict[str, Dict]
            Dictionary of loaded datasets.
        """
        self.datasets = datasets
        self.integrated_data: Optional[pd.DataFrame] = None
    
    def create_integrated_dataset(self) -> pd.DataFrame:
        """
        Create integrated dataset by merging biomarkers and cognitive assessments.
        
        Returns
        -------
        pd.DataFrame
            Integrated dataset.
        """
        # Get required datasets
        upenn = self.datasets.get('UPENN_PLASMA_FUJIREBIO_QUANTERIX_13Feb2026', {}).get('df')
        moca = self.datasets.get('MOCA_13Feb2026', {}).get('df')
        adas = self.datasets.get('ADAS_13Feb2026', {}).get('df')
        cdr = self.datasets.get('CDR_13Feb2026', {}).get('df')
        
        if upenn is None:
            raise ValueError("UPENN plasma dataset required for integration")
        
        # Start with biomarkers
        bio_cols = ['RID', 'VISCODE2', 'PHASE', 'pT217_F', 'AB42_F', 'AB40_F', 
                   'AB42_AB40_F', 'NfL_Q', 'GFAP_Q']
        integrated = upenn[[col for col in bio_cols if col in upenn.columns]].copy()
        
        # Filter valid biomarker values
        for col in ['pT217_F', 'AB42_F', 'AB40_F', 'AB42_AB40_F', 'NfL_Q', 'GFAP_Q']:
            if col in integrated.columns:
                integrated[col] = integrated[col].where(integrated[col] >= 0)
        
        # Merge with MoCA
        if moca is not None and 'VISCODE2' in moca.columns:
            moca_cols = ['RID', 'VISCODE2', 'MOCA']
            moca_data = moca[[col for col in moca_cols if col in moca.columns]].copy()
            moca_data['MOCA'] = moca_data['MOCA'].where(moca_data['MOCA'] >= 0)
            
            integrated = integrated.merge(moca_data, on=['RID', 'VISCODE2'], 
                                         how='left', suffixes=('', '_moca'))
        
        # Merge with ADAS
        if adas is not None and 'VISCODE2' in adas.columns:
            adas_cols = ['RID', 'VISCODE2', 'TOTSCORE', 'TOTAL13']
            adas_data = adas[[col for col in adas_cols if col in adas.columns]].copy()
            for col in ['TOTSCORE', 'TOTAL13']:
                if col in adas_data.columns:
                    adas_data[col] = adas_data[col].where(adas_data[col] >= 0)
            
            integrated = integrated.merge(adas_data, on=['RID', 'VISCODE2'], 
                                         how='left', suffixes=('', '_adas'))
        
        # Merge with CDR
        if cdr is not None and 'VISCODE2' in cdr.columns:
            cdr_cols = ['RID', 'VISCODE2', 'CDRSB', 'CDGLOBAL']
            cdr_data = cdr[[col for col in cdr_cols if col in cdr.columns]].copy()
            for col in ['CDRSB', 'CDGLOBAL']:
                if col in cdr_data.columns:
                    cdr_data[col] = cdr_data[col].where(cdr_data[col] >= 0)
            
            integrated = integrated.merge(cdr_data, on=['RID', 'VISCODE2'], 
                                         how='left', suffixes=('', '_cdr'))
        
        self.integrated_data = integrated
        return integrated
    
    def analyze_feature_variance(self, feature_cols: List[str]) -> pd.DataFrame:
        """
        Analyze variance of features.
        
        Parameters
        ----------
        feature_cols : List[str]
            Feature columns to analyze.
            
        Returns
        -------
        pd.DataFrame
            Feature variance analysis.
        """
        if self.integrated_data is None:
            self.create_integrated_dataset()
        
        results = []
        
        for col in feature_cols:
            if col not in self.integrated_data.columns:
                continue
            
            data = self.integrated_data[col].dropna()
            if len(data) == 0:
                continue
            
            mean = data.mean()
            std = data.std()
            cv = std / mean if mean != 0 else np.nan
            
            results.append({
                'Feature': col,
                'N': len(data),
                'Mean': mean,
                'Std': std,
                'CV': cv,
                'Variance': data.var(),
                'Near_Zero_Variance': cv < 0.01,
            })
        
        return pd.DataFrame(results)
    
    def analyze_multicollinearity(self, feature_cols: List[str]) -> Dict:
        """
        Analyze multicollinearity between features.
        
        Parameters
        ----------
        feature_cols : List[str]
            Feature columns to analyze.
            
        Returns
        -------
        Dict
            Multicollinearity analysis results.
        """
        if self.integrated_data is None:
            self.create_integrated_dataset()
        
        # Filter to available columns
        available_cols = [col for col in feature_cols if col in self.integrated_data.columns]
        
        if len(available_cols) < 2:
            return {'error': 'Need at least 2 features'}
        
        # Calculate correlation matrix
        corr_matrix = self.integrated_data[available_cols].corr()
        
        # Find highly correlated pairs
        high_corr_pairs = []
        for i in range(len(available_cols)):
            for j in range(i + 1, len(available_cols)):
                r = corr_matrix.iloc[i, j]
                if abs(r) > 0.7:
                    high_corr_pairs.append({
                        'Feature_1': available_cols[i],
                        'Feature_2': available_cols[j],
                        'Correlation': r,
                    })
        
        return {
            'correlation_matrix': corr_matrix,
            'high_correlation_pairs': pd.DataFrame(high_corr_pairs),
            'n_high_correlations': len(high_corr_pairs),
        }
    
    def analyze_missing_data_pattern(self, feature_cols: List[str]) -> pd.DataFrame:
        """
        Analyze missing data patterns.
        
        Parameters
        ----------
        feature_cols : List[str]
            Feature columns to analyze.
            
        Returns
        -------
        pd.DataFrame
            Missing data analysis.
        """
        if self.integrated_data is None:
            self.create_integrated_dataset()
        
        results = []
        
        for col in feature_cols:
            if col not in self.integrated_data.columns:
                continue
            
            n_missing = self.integrated_data[col].isnull().sum()
            pct_missing = (n_missing / len(self.integrated_data)) * 100
            
            results.append({
                'Feature': col,
                'N_Missing': n_missing,
                'Missing_Pct': pct_missing,
                'Severity': 'High' if pct_missing > 30 else 'Moderate' if pct_missing > 10 else 'Low',
            })
        
        return pd.DataFrame(results)
    
    def analyze_complete_cases(self, feature_cols: List[str]) -> Dict:
        """
        Analyze complete cases for ML.
        
        Parameters
        ----------
        feature_cols : List[str]
            Feature columns to analyze.
            
        Returns
        -------
        Dict
            Complete cases analysis.
        """
        if self.integrated_data is None:
            self.create_integrated_dataset()
        
        available_cols = [col for col in feature_cols if col in self.integrated_data.columns]
        
        # Complete cases (all features)
        complete = self.integrated_data[available_cols].dropna()
        
        # Cases with at least one biomarker
        bio_cols = ['pT217_F', 'AB42_AB40_F', 'NfL_Q', 'GFAP_Q']
        bio_available = [col for col in bio_cols if col in self.integrated_data.columns]
        has_bio = self.integrated_data[bio_available].notna().any(axis=1)
        
        # Cases with cognitive
        cog_cols = ['MOCA', 'TOTSCORE']
        cog_available = [col for col in cog_cols if col in self.integrated_data.columns]
        has_cog = self.integrated_data[cog_available].notna().any(axis=1)
        
        return {
            'total_records': len(self.integrated_data),
            'complete_cases': len(complete),
            'complete_cases_pct': len(complete) / len(self.integrated_data) * 100,
            'has_biomarker': has_bio.sum(),
            'has_cognitive': has_cog.sum(),
            'has_both': (has_bio & has_cog).sum(),
        }
    
    def analyze_target_variable(self, target_col: str = 'CDGLOBAL') -> Dict:
        """
        Analyze target variable for ML.
        
        Parameters
        ----------
        target_col : str
            Target column name.
            
        Returns
        -------
        Dict
            Target variable analysis.
        """
        if self.integrated_data is None:
            self.create_integrated_dataset()
        
        if target_col not in self.integrated_data.columns:
            return {'error': f'Target column {target_col} not found'}
        
        target = self.integrated_data[target_col].dropna()
        target = target[target >= 0]
        
        # Distribution
        distribution = target.value_counts().sort_index().to_dict()
        
        # Binary targets
        binary_targets = {}
        if target_col == 'CDGLOBAL':
            binary_targets['CDR_Positive'] = {
                'n': (target > 0).sum(),
                'pct': (target > 0).mean() * 100,
            }
            binary_targets['MCI_Dementia'] = {
                'n': (target >= 0.5).sum(),
                'pct': (target >= 0.5).mean() * 100,
            }
        
        # Class imbalance
        if len(distribution) >= 2:
            counts = list(distribution.values())
            imbalance_ratio = max(counts) / min(counts)
        else:
            imbalance_ratio = None
        
        return {
            'target_column': target_col,
            'n_valid': len(target),
            'distribution': distribution,
            'binary_targets': binary_targets,
            'imbalance_ratio': imbalance_ratio,
        }
    
    def full_ml_assessment(self) -> Dict:
        """
        Perform full ML readiness assessment.
        
        Returns
        -------
        Dict
            Complete ML readiness assessment.
        """
        # Feature columns for assessment
        feature_cols = ['pT217_F', 'AB42_AB40_F', 'NfL_Q', 'GFAP_Q', 'MOCA', 'TOTSCORE']
        
        results = {
            'feature_variance': self.analyze_feature_variance(feature_cols),
            'multicollinearity': self.analyze_multicollinearity(feature_cols),
            'missing_data': self.analyze_missing_data_pattern(feature_cols),
            'complete_cases': self.analyze_complete_cases(feature_cols),
            'target_analysis': self.analyze_target_variable('CDGLOBAL'),
        }
        
        return results
    
    def print_ml_report(self):
        """Print ML readiness report to console."""
        results = self.full_ml_assessment()
        
        print("=" * 100)
        print("MACHINE LEARNING READINESS ASSESSMENT")
        print("=" * 100)
        
        # Feature variance
        print("\n--- FEATURE VARIANCE ANALYSIS ---")
        print(results['feature_variance'].to_string(index=False))
        
        # Multicollinearity
        print("\n--- MULTICOLLINEARITY ANALYSIS ---")
        if 'correlation_matrix' in results['multicollinearity']:
            print("\nCorrelation Matrix:")
            print(results['multicollinearity']['correlation_matrix'].round(3).to_string())
            
            if results['multicollinearity']['n_high_correlations'] > 0:
                print("\nHigh Correlation Pairs (|r| > 0.7):")
                print(results['multicollinearity']['high_correlation_pairs'].to_string(index=False))
            else:
                print("\nNo high correlations detected (good for ML)")
        
        # Missing data
        print("\n--- MISSING DATA PATTERN ---")
        print(results['missing_data'].to_string(index=False))
        
        # Complete cases
        print("\n--- COMPLETE CASES ANALYSIS ---")
        cc = results['complete_cases']
        print(f"Total Records: {cc['total_records']:,}")
        print(f"Complete Cases: {cc['complete_cases']:,} ({cc['complete_cases_pct']:.1f}%)")
        print(f"Has Biomarker: {cc['has_biomarker']:,}")
        print(f"Has Cognitive: {cc['has_cognitive']:,}")
        print(f"Has Both: {cc['has_both']:,}")
        
        # Target analysis
        print("\n--- TARGET VARIABLE ANALYSIS ---")
        ta = results['target_analysis']
        print(f"Target: {ta['target_column']}")
        print(f"Valid Samples: {ta['n_valid']:,}")
        print(f"\nDistribution: {ta['distribution']}")
        
        if ta['binary_targets']:
            print("\nBinary Targets:")
            for name, info in ta['binary_targets'].items():
                print(f"  {name}: {info['n']:,} ({info['pct']:.1f}%)")
        
        if ta['imbalance_ratio']:
            print(f"\nClass Imbalance Ratio: {ta['imbalance_ratio']:.2f}:1")


if __name__ == '__main__':
    # Example usage
    from src.data.loader import load_and_preprocess_adni_data
    
    datasets, _ = load_and_preprocess_adni_data()
    
    analyzer = MLReadinessAnalyzer(datasets)
    analyzer.print_ml_report()
