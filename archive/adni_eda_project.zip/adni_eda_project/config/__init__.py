"""
ADNI EDA Configuration Module
=============================
Centralized configuration settings.
"""

from .settings import (
    DATA_DIR,
    OUTPUT_DIR,
    SENTINEL_VALUES,
    FILE_CATEGORIES,
    ID_COLUMNS,
    BIOMARKER_COLUMNS,
    COGNITIVE_COLUMNS,
    IMAGING_COLUMNS,
    COLORS,
)

__all__ = [
    'DATA_DIR',
    'OUTPUT_DIR',
    'SENTINEL_VALUES',
    'FILE_CATEGORIES',
    'ID_COLUMNS',
    'BIOMARKER_COLUMNS',
    'COGNITIVE_COLUMNS',
    'IMAGING_COLUMNS',
    'COLORS',
]
