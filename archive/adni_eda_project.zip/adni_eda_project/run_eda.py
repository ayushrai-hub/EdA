#!/usr/bin/env python3
"""
ADNI Comprehensive EDA Runner
=============================
Main script to run the complete EDA pipeline.

Usage:
    python run_eda.py [--data-dir PATH] [--output-dir PATH]

Example:
    python run_eda.py --data-dir /path/to/adni/data --output-dir ./output
"""

import argparse
import sys
from pathlib import Path
from datetime import datetime

# Add project root to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from src.data.loader import load_and_preprocess_adni_data
from src.analysis.schema_analyzer import SchemaAnalyzer
from src.analysis.statistical_analyzer import StatisticalAnalyzer
from src.analysis.longitudinal_analyzer import LongitudinalAnalyzer
from src.analysis.ml_readiness import MLReadinessAnalyzer
from src.visualization.plots import ADNIVisualizer

from config.settings import DATA_DIR, OUTPUT_DIR


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description='ADNI Comprehensive Exploratory Data Analysis'
    )
    parser.add_argument(
        '--data-dir', 
        type=Path, 
        default=DATA_DIR,
        help='Directory containing ADNI CSV files'
    )
    parser.add_argument(
        '--output-dir', 
        type=Path, 
        default=OUTPUT_DIR,
        help='Directory for output files'
    )
    parser.add_argument(
        '--skip-viz',
        action='store_true',
        help='Skip visualization generation'
    )
    return parser.parse_args()


def run_eda_pipeline(data_dir: Path, output_dir: Path, skip_viz: bool = False):
    """
    Run the complete EDA pipeline.
    
    Parameters
    ----------
    data_dir : Path
        Directory containing ADNI CSV files.
    output_dir : Path
        Directory for output files.
    skip_viz : bool
        Whether to skip visualization generation.
    """
    print("=" * 100)
    print("ADNI COMPREHENSIVE EXPLORATORY DATA ANALYSIS")
    print("=" * 100)
    print(f"\nStarted: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Data Directory: {data_dir}")
    print(f"Output Directory: {output_dir}")
    
    # =========================================================================
    # PHASE 1: Data Loading
    # =========================================================================
    print("\n" + "=" * 100)
    print("PHASE 1: DATA LOADING AND PREPROCESSING")
    print("=" * 100)
    
    datasets, summary_df = load_and_preprocess_adni_data(data_dir)
    
    # Save dataset summary
    summary_df.to_csv(output_dir / 'tables' / 'dataset_summary.csv', index=False)
    print(f"\n✓ Loaded {len(datasets)} datasets")
    print(f"✓ Saved dataset summary to: output/tables/dataset_summary.csv")
    
    # =========================================================================
    # PHASE 2: Schema Analysis
    # =========================================================================
    print("\n" + "=" * 100)
    print("PHASE 2: SCHEMA ANALYSIS")
    print("=" * 100)
    
    schema_analyzer = SchemaAnalyzer(datasets)
    schema_info = schema_analyzer.analyze_all()
    
    # Save schema analysis
    schema_df = schema_analyzer.get_summary_table()
    schema_df.to_csv(output_dir / 'tables' / 'schema_analysis.csv', index=False)
    print(f"✓ Saved schema analysis to: output/tables/schema_analysis.csv")
    
    # Print join analysis
    join_analysis = schema_analyzer.get_join_analysis()
    print("\n--- Join Key Availability ---")
    print(join_analysis.to_string(index=False))
    
    # Print relationship map
    rel_map = schema_analyzer.get_relationship_map()
    print("\n--- Relationship Map ---")
    for key_type, datasets_list in rel_map.items():
        print(f"  {key_type}: {len(datasets_list)} datasets")
    
    # =========================================================================
    # PHASE 3: Statistical Analysis
    # =========================================================================
    print("\n" + "=" * 100)
    print("PHASE 3: STATISTICAL ANALYSIS")
    print("=" * 100)
    
    stat_analyzer = StatisticalAnalyzer(datasets)
    
    # Biomarker analysis
    print("\n--- Biomarker Analysis ---")
    bio_results = stat_analyzer.analyze_biomarkers()
    print(f"Dataset: {bio_results['dataset']}")
    print(f"Total samples: {bio_results['total_samples']:,}")
    print(f"Unique participants: {bio_results['unique_participants']:,}")
    print("\nDescriptive Statistics:")
    print(bio_results['descriptive_stats'].round(4).to_string(index=False))
    
    # Save biomarker statistics
    bio_results['descriptive_stats'].to_csv(
        output_dir / 'tables' / 'biomarker_statistics.csv', index=False
    )
    bio_results['outliers_iqr'].to_csv(
        output_dir / 'tables' / 'biomarker_outliers.csv', index=False
    )
    
    # Cognitive analysis
    print("\n--- Cognitive Assessment Analysis ---")
    cog_results = stat_analyzer.analyze_cognitive_assessments()
    for name, result in cog_results.items():
        print(f"\n{name}:")
        print(f"  Total assessments: {result['total_assessments']:,}")
        print(f"  Unique participants: {result['unique_participants']:,}")
        print("  Descriptive Statistics:")
        print(result['descriptive_stats'].round(2).to_string(index=False))
    
    # Imaging analysis
    print("\n--- Imaging Analysis ---")
    img_results = stat_analyzer.analyze_imaging()
    print(f"Dataset: {img_results['dataset']}")
    print(f"Total scans: {img_results['total_scans']:,}")
    print(f"Unique participants: {img_results['unique_participants']:,}")
    print("\nDescriptive Statistics:")
    print(img_results['descriptive_stats'].round(2).to_string(index=False))
    
    # Multimodal correlations
    print("\n--- Multimodal Correlation Analysis ---")
    corr_results = stat_analyzer.multimodal_correlation_analysis()
    
    if 'biomarker_cognitive' in corr_results:
        bc = corr_results['biomarker_cognitive']
        print(f"\nBiomarker-Cognitive Correlations (n={bc['n_records']:,} records):")
        print(bc['correlation_matrix'].round(3).to_string())
        bc['correlation_matrix'].to_csv(
            output_dir / 'tables' / 'correlation_matrix.csv'
        )
    
    if 'biomarker_imaging' in corr_results:
        bi = corr_results['biomarker_imaging']
        print(f"\nBiomarker-Imaging Correlations (n={bi['n_participants']:,} participants):")
        print(bi['correlation_matrix'].round(3).to_string())
    
    # =========================================================================
    # PHASE 4: Longitudinal Analysis
    # =========================================================================
    print("\n" + "=" * 100)
    print("PHASE 4: LONGITUDINAL ANALYSIS")
    print("=" * 100)
    
    long_analyzer = LongitudinalAnalyzer(datasets)
    
    # Visit patterns
    print("\n--- Visit Patterns ---")
    visit_summary = long_analyzer.get_visit_summary_table()
    print(visit_summary.to_string(index=False))
    visit_summary.to_csv(output_dir / 'tables' / 'visit_patterns.csv', index=False)
    
    # Study phases
    print("\n--- Study Phase Distribution ---")
    phase_dist = long_analyzer.get_study_phase_distribution()
    print(phase_dist.to_string(index=False))
    
    # Temporal coverage
    print("\n--- Temporal Coverage ---")
    temporal = long_analyzer.analyze_temporal_coverage()
    print(temporal.to_string(index=False))
    
    # =========================================================================
    # PHASE 5: ML Readiness Assessment
    # =========================================================================
    print("\n" + "=" * 100)
    print("PHASE 5: MACHINE LEARNING READINESS ASSESSMENT")
    print("=" * 100)
    
    ml_analyzer = MLReadinessAnalyzer(datasets)
    ml_results = ml_analyzer.full_ml_assessment()
    
    # Feature variance
    print("\n--- Feature Variance ---")
    print(ml_results['feature_variance'].round(4).to_string(index=False))
    ml_results['feature_variance'].to_csv(
        output_dir / 'tables' / 'ml_feature_variance.csv', index=False
    )
    
    # Multicollinearity
    print("\n--- Multicollinearity ---")
    if 'correlation_matrix' in ml_results['multicollinearity']:
        print(ml_results['multicollinearity']['correlation_matrix'].round(3).to_string())
    
    # Complete cases
    print("\n--- Complete Cases ---")
    cc = ml_results['complete_cases']
    print(f"Total Records: {cc['total_records']:,}")
    print(f"Complete Cases: {cc['complete_cases']:,} ({cc['complete_cases_pct']:.1f}%)")
    
    # Target analysis
    print("\n--- Target Variable Analysis ---")
    ta = ml_results['target_analysis']
    if 'distribution' in ta:
        print(f"Target: {ta['target_column']}")
        print(f"Distribution: {ta['distribution']}")
        if ta.get('imbalance_ratio'):
            print(f"Imbalance Ratio: {ta['imbalance_ratio']:.2f}:1")
    
    # =========================================================================
    # PHASE 6: Visualization
    # =========================================================================
    if not skip_viz:
        print("\n" + "=" * 100)
        print("PHASE 6: GENERATING VISUALIZATIONS")
        print("=" * 100)
        
        visualizer = ADNIVisualizer(output_dir / 'visualizations')
        visualizer.create_all_visualizations(datasets, schema_info, summary_df)
    
    # =========================================================================
    # COMPLETION
    # =========================================================================
    print("\n" + "=" * 100)
    print("EDA PIPELINE COMPLETED SUCCESSFULLY")
    print("=" * 100)
    print(f"\nFinished: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"\nOutput files saved to: {output_dir}")
    print("\nGenerated files:")
    print("  - Reports: output/reports/")
    print("  - Tables: output/tables/")
    print("  - Visualizations: output/visualizations/")


def main():
    """Main entry point."""
    args = parse_arguments()
    
    # Create output directories
    (args.output_dir / 'reports').mkdir(parents=True, exist_ok=True)
    (args.output_dir / 'tables').mkdir(parents=True, exist_ok=True)
    (args.output_dir / 'visualizations').mkdir(parents=True, exist_ok=True)
    
    # Run pipeline
    run_eda_pipeline(args.data_dir, args.output_dir, args.skip_viz)


if __name__ == '__main__':
    main()
