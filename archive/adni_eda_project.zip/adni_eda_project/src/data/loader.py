"""
ADNI Data Loader Module
=======================
Handles loading, validation, and initial preprocessing of ADNI CSV files.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import hashlib
import warnings

from config.settings import (
    DATA_DIR, SENTINEL_VALUES, FILES_TO_EXCLUDE, FILE_CATEGORIES
)

warnings.filterwarnings('ignore')


class ADNILoader:
    """
    Loader for ADNI CSV datasets with automatic duplicate detection
    and data validation.
    """
    
    def __init__(self, data_dir: Optional[Path] = None):
        """
        Initialize the ADNI data loader.
        
        Parameters
        ----------
        data_dir : Path, optional
            Directory containing ADNI CSV files. Defaults to DATA_DIR.
        """
        self.data_dir = data_dir or DATA_DIR
        self.datasets: Dict[str, Dict] = {}
        self.duplicate_groups: Dict[str, List[str]] = {}
        
    def _compute_file_hash(self, filepath: Path) -> str:
        """Compute MD5 hash of a file for duplicate detection."""
        with open(filepath, 'rb') as f:
            return hashlib.md5(f.read()).hexdigest()
    
    def find_duplicates(self) -> Dict[str, List[str]]:
        """
        Find duplicate files based on MD5 hash.
        
        Returns
        -------
        Dict[str, List[str]]
            Dictionary mapping hash values to lists of duplicate filenames.
        """
        csv_files = sorted(self.data_dir.glob('*.csv'))
        hash_groups: Dict[str, List[str]] = {}
        
        for f in csv_files:
            file_hash = self._compute_file_hash(f)
            if file_hash not in hash_groups:
                hash_groups[file_hash] = []
            hash_groups[file_hash].append(f.name)
        
        # Keep only groups with duplicates
        self.duplicate_groups = {
            h: files for h, files in hash_groups.items() if len(files) > 1
        }
        
        return self.duplicate_groups
    
    def get_unique_files(self) -> List[Path]:
        """
        Get list of unique (non-duplicate) CSV files.
        
        Returns
        -------
        List[Path]
            List of Path objects for unique CSV files.
        """
        all_files = sorted(self.data_dir.glob('*.csv'))
        
        # Find duplicates if not already done
        if not self.duplicate_groups:
            self.find_duplicates()
        
        # Get files to exclude (duplicates with suffixes)
        files_to_exclude_set = set(FILES_TO_EXCLUDE)
        
        # Add duplicates to exclusion (keep first in each group)
        for files in self.duplicate_groups.values():
            # Sort to keep the one without suffix
            sorted_files = sorted(files, key=lambda x: ('(1)' in x, '(2)' in x, '(3)' in x))
            files_to_exclude_set.update(sorted_files[1:])
        
        unique_files = [f for f in all_files if f.name not in files_to_exclude_set]
        return unique_files
    
    def load_csv(self, filepath: Path) -> Optional[pd.DataFrame]:
        """
        Load a single CSV file with multiple encoding attempts.
        
        Parameters
        ----------
        filepath : Path
            Path to CSV file.
            
        Returns
        -------
        pd.DataFrame or None
            Loaded DataFrame or None if loading fails.
        """
        encodings = ['utf-8', 'latin-1', 'iso-8859-1', 'cp1252']
        
        for encoding in encodings:
            try:
                df = pd.read_csv(filepath, encoding=encoding, low_memory=False)
                return df
            except UnicodeDecodeError:
                continue
            except Exception as e:
                print(f"Error loading {filepath.name}: {e}")
                return None
        
        print(f"Failed to load {filepath.name} with any encoding")
        return None
    
    def load_all_datasets(self) -> Dict[str, Dict]:
        """
        Load all unique datasets from the data directory.
        
        Returns
        -------
        Dict[str, Dict]
            Dictionary mapping dataset names to their data and metadata.
        """
        unique_files = self.get_unique_files()
        
        print(f"Loading {len(unique_files)} unique datasets...\n")
        
        for f in unique_files:
            df = self.load_csv(f)
            if df is not None:
                # Determine category
                category = 'uncategorized'
                for cat, files in FILE_CATEGORIES.items():
                    if f.name in files:
                        category = cat
                        break
                
                self.datasets[f.stem] = {
                    'df': df,
                    'filename': f.name,
                    'category': category,
                    'shape': df.shape,
                }
                print(f"✓ {f.name}: {df.shape[0]:,} rows × {df.shape[1]} columns")
        
        print(f"\nSuccessfully loaded {len(self.datasets)} datasets")
        return self.datasets
    
    def get_dataset(self, name: str) -> Optional[pd.DataFrame]:
        """
        Get a specific dataset by name.
        
        Parameters
        ----------
        name : str
            Dataset name (stem of filename).
            
        Returns
        -------
        pd.DataFrame or None
            The requested dataset or None if not found.
        """
        if name in self.datasets:
            return self.datasets[name]['df']
        return None
    
    def get_datasets_by_category(self, category: str) -> Dict[str, pd.DataFrame]:
        """
        Get all datasets in a specific category.
        
        Parameters
        ----------
        category : str
            Category name ('biospecimen', 'neuropsychological', 'imaging_mri').
            
        Returns
        -------
        Dict[str, pd.DataFrame]
            Dictionary of dataset names to DataFrames.
        """
        return {
            name: data['df'] 
            for name, data in self.datasets.items() 
            if data['category'] == category
        }
    
    def get_summary(self) -> pd.DataFrame:
        """
        Get summary statistics for all loaded datasets.
        
        Returns
        -------
        pd.DataFrame
            Summary table of all datasets.
        """
        summaries = []
        for name, data in self.datasets.items():
            df = data['df']
            summaries.append({
                'Dataset': name,
                'Category': data['category'],
                'Rows': df.shape[0],
                'Columns': df.shape[1],
                'Memory_MB': round(df.memory_usage(deep=True).sum() / (1024 * 1024), 2),
            })
        
        return pd.DataFrame(summaries)


def normalize_missing_values(df: pd.DataFrame, sentinel_values: Optional[List] = None) -> pd.DataFrame:
    """
    Replace sentinel values with NaN in a DataFrame.
    
    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame.
    sentinel_values : list, optional
        List of values to treat as missing. Defaults to SENTINEL_VALUES.
        
    Returns
    -------
    pd.DataFrame
        DataFrame with sentinel values replaced by NaN.
    """
    if sentinel_values is None:
        sentinel_values = SENTINEL_VALUES
    
    df_clean = df.copy()
    
    for col in df_clean.columns:
        if df_clean[col].dtype in ['object', 'string']:
            # Replace sentinel strings
            df_clean[col] = df_clean[col].replace(sentinel_values, np.nan)
            
            # Try to convert to numeric
            try:
                numeric_col = pd.to_numeric(df_clean[col], errors='coerce')
                if numeric_col.notna().sum() > 0:
                    df_clean[col] = numeric_col
            except:
                pass
        else:
            # For numeric columns, replace sentinel values
            df_clean[col] = df_clean[col].replace([-4, -4.0, -999, -999.0], np.nan)
    
    return df_clean


def detect_date_columns(df: pd.DataFrame) -> List[str]:
    """
    Detect columns that appear to contain dates based on column names.
    
    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame.
        
    Returns
    -------
    List[str]
        List of column names that appear to be dates.
    """
    from config.settings import DATE_COLUMN_PATTERNS
    
    date_cols = []
    for col in df.columns:
        col_lower = col.lower()
        if any(pattern.lower() in col_lower for pattern in DATE_COLUMN_PATTERNS):
            date_cols.append(col)
    
    return date_cols


def parse_date_columns(df: pd.DataFrame, date_cols: Optional[List[str]] = None) -> pd.DataFrame:
    """
    Parse date columns to datetime format.
    
    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame.
    date_cols : list, optional
        List of column names to parse as dates. If None, auto-detect.
        
    Returns
    -------
    pd.DataFrame
        DataFrame with parsed date columns.
    """
    df_parsed = df.copy()
    
    if date_cols is None:
        date_cols = detect_date_columns(df)
    
    for col in date_cols:
        if col in df_parsed.columns:
            try:
                df_parsed[col] = pd.to_datetime(df_parsed[col], errors='coerce')
            except:
                pass
    
    return df_parsed


# Convenience function for full data loading pipeline
def load_and_preprocess_adni_data(data_dir: Optional[Path] = None) -> Tuple[Dict[str, Dict], pd.DataFrame]:
    """
    Complete pipeline: load all ADNI data, normalize missing values, and parse dates.
    
    Parameters
    ----------
    data_dir : Path, optional
        Directory containing ADNI CSV files.
        
    Returns
    -------
    Tuple[Dict[str, Dict], pd.DataFrame]
        Tuple of (datasets dictionary, summary DataFrame).
    """
    loader = ADNILoader(data_dir)
    datasets = loader.load_all_datasets()
    
    # Preprocess each dataset
    for name, data in datasets.items():
        df = data['df']
        
        # Normalize missing values
        df = normalize_missing_values(df)
        
        # Detect and parse date columns
        date_cols = detect_date_columns(df)
        df = parse_date_columns(df, date_cols)
        
        # Update dataset
        datasets[name]['df'] = df
        datasets[name]['date_columns'] = date_cols
    
    # Get summary
    summary = loader.get_summary()
    
    return datasets, summary


if __name__ == '__main__':
    # Example usage
    datasets, summary = load_and_preprocess_adni_data()
    print("\nDataset Summary:")
    print(summary.to_string(index=False))
