"""
ADNI PET Imaging Analysis Module
================================
Comprehensive analysis of PET (Amyloid, Tau, FDG) imaging data.

Usage:
    from adni_pet_analysis import load_pet_data, analyze_pet_biomarkers

    datasets = load_pet_data('/path/to/pet/csv/files')
    results = analyze_pet_biomarkers(datasets)
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import warnings
warnings.filterwarnings('ignore')


# =============================================================================
# CONFIGURATION
# =============================================================================

PET_FILE_CATEGORIES = {
    'amyloid_pet': [
        'AMYMETA_13Feb2026.csv',
        'AMYQC_13Feb2026.csv',
        'BAIPETNMRCAV45_10_23_20_13Feb2026.csv',
    ],
    'tau_pet': [
        'TAUMETA_13Feb2026.csv',
        'TAUQC_13Feb2026.csv',
        'UCBERKELEY_TAU_6MM_13Feb2026.csv',
        'UCBERKELEY_TAUPVC_6MM_13Feb2026.csv',
    ],
    'fdg_pet': [
        'BAIPETNMRCFDG_12_11_20_13Feb2026.csv',
        'NYUFDGHIP_13Feb2026.csv',
        'UCBERKELEYFDG_8mm_02_17_23_13Feb2026.csv',
    ],
    'pet_metadata': [
        'PETMETA_ADNI1_13Feb2026.csv',
        'PETQC_13Feb2026.csv',
        'CROSSVAL_13Feb2026.csv',
    ],
}

SENTINEL_VALUES = [-4, -4.0, '-4', -999, -999.0, '', 'NA', 'N/A', 'NULL', 'None']


# =============================================================================
# DATA LOADING
# =============================================================================

def normalize_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    """Replace sentinel values with NaN."""
    df_clean = df.copy()
    for col in df_clean.columns:
        if df_clean[col].dtype in ['object', 'string']:
            df_clean[col] = df_clean[col].replace(SENTINEL_VALUES, np.nan)
            try:
                numeric_col = pd.to_numeric(df_clean[col], errors='coerce')
                if numeric_col.notna().sum() > 0:
                    df_clean[col] = numeric_col
            except:
                pass
        else:
            df_clean[col] = df_clean[col].replace([-4, -4.0, -999, -999.0], np.nan)
    return df_clean


def parse_date_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Parse date columns to datetime."""
    df_parsed = df.copy()
    for col in df_parsed.columns:
        if any(keyword in col.lower() for keyword in ['date', 'stamp', 'time']):
            try:
                df_parsed[col] = pd.to_datetime(df_parsed[col], errors='coerce')
            except:
                pass
    return df_parsed


def load_pet_data(data_dir: Path) -> Dict[str, Dict]:
    """
    Load all PET imaging datasets.

    Parameters
    ----------
    data_dir : Path
        Directory containing PET CSV files.

    Returns
    -------
    Dict[str, Dict]
        Dictionary of loaded PET datasets.
    """
    datasets = {}

    # Flatten file list
    all_files = []
    for cat, files in PET_FILE_CATEGORIES.items():
        for f in files:
            all_files.append((f, cat))

    for filename, category in all_files:
        filepath = data_dir / filename
        if not filepath.exists():
            print(f"⚠ File not found: {filename}")
            continue

        try:
            for encoding in ['utf-8', 'latin-1', 'iso-8859-1']:
                try:
                    df = pd.read_csv(filepath, encoding=encoding, low_memory=False)
                    break
                except UnicodeDecodeError:
                    continue

            df = normalize_missing_values(df)
            df = parse_date_columns(df)

            stem = Path(filename).stem
            datasets[stem] = {
                'df': df,
                'filename': filename,
                'category': category,
            }
            print(f"✓ Loaded {filename}: {df.shape[0]:,} rows × {df.shape[1]} columns")

        except Exception as e:
            print(f"✗ Error loading {filename}: {e}")

    print(f"\nLoaded {len(datasets)} PET datasets")
    return datasets


# =============================================================================
# BIOMARKER ANALYSIS
# =============================================================================

def analyze_av45_amyloid(datasets: Dict) -> pd.DataFrame:
    """Analyze AV45 Amyloid PET data."""
    if 'BAIPETNMRCAV45_10_23_20_13Feb2026' not in datasets:
        return pd.DataFrame()

    df = datasets['BAIPETNMRCAV45_10_23_20_13Feb2026']['df']

    results = []
    for col in ['MCSUVRWM', 'MCSUVRCERE']:
        if col in df.columns:
            data = df[col].dropna()
            data = data[data >= 0]
            results.append({
                'Biomarker': f'AV45_{col}',
                'N': len(data),
                'Mean': data.mean(),
                'Std': data.std(),
                'Min': data.min(),
                'Q1': data.quantile(0.25),
                'Median': data.median(),
                'Q3': data.quantile(0.75),
                'Max': data.max(),
            })

    return pd.DataFrame(results)


def analyze_tau_pet(datasets: Dict) -> pd.DataFrame:
    """Analyze Tau PET data."""
    if 'UCBERKELEY_TAU_6MM_13Feb2026' not in datasets:
        return pd.DataFrame()

    df = datasets['UCBERKELEY_TAU_6MM_13Feb2026']['df']

    results = []
    for col in ['META_TEMPORAL_SUVR']:
        if col in df.columns:
            data = df[col].dropna()
            data = data[data >= 0]
            results.append({
                'Biomarker': f'Tau_{col}',
                'N': len(data),
                'Mean': data.mean(),
                'Std': data.std(),
                'Min': data.min(),
                'Q1': data.quantile(0.25),
                'Median': data.median(),
                'Q3': data.quantile(0.75),
                'Max': data.max(),
            })

    return pd.DataFrame(results)


def analyze_fdg_pet(datasets: Dict) -> pd.DataFrame:
    """Analyze FDG PET data."""
    results = []

    # BAI FDG
    if 'BAIPETNMRCFDG_12_11_20_13Feb2026' in datasets:
        df = datasets['BAIPETNMRCFDG_12_11_20_13Feb2026']['df']
        for col in ['SROI.AD', 'SROI.MCI']:
            if col in df.columns:
                data = df[col].dropna()
                data = data[data >= 0]
                results.append({
                    'Biomarker': f'FDG_{col}',
                    'N': len(data),
                    'Mean': data.mean(),
                    'Std': data.std(),
                    'Min': data.min(),
                    'Q1': data.quantile(0.25),
                    'Median': data.median(),
                    'Q3': data.quantile(0.75),
                    'Max': data.max(),
                })

    # UC Berkeley FDG MetaROI
    if 'UCBERKELEYFDG_8mm_02_17_23_13Feb2026' in datasets:
        df = datasets['UCBERKELEYFDG_8mm_02_17_23_13Feb2026']['df']
        metaroi = df[df['ROINAME'] == 'MetaROI']['MEAN'].dropna()
        metaroi = metaroi[metaroi > 0]
        results.append({
            'Biomarker': 'FDG_METAROI_SUVR',
            'N': len(metaroi),
            'Mean': metaroi.mean(),
            'Std': metaroi.std(),
            'Min': metaroi.min(),
            'Q1': metaroi.quantile(0.25),
            'Median': metaroi.median(),
            'Q3': metaroi.quantile(0.75),
            'Max': metaroi.max(),
        })

    return pd.DataFrame(results)


def analyze_pet_biomarkers(datasets: Dict) -> Dict[str, pd.DataFrame]:
    """
    Analyze all PET biomarkers.

    Returns
    -------
    Dict[str, pd.DataFrame]
        Dictionary of biomarker analysis results.
    """
    return {
        'amyloid': analyze_av45_amyloid(datasets),
        'tau': analyze_tau_pet(datasets),
        'fdg': analyze_fdg_pet(datasets),
    }


# =============================================================================
# CORRELATION ANALYSIS
# =============================================================================

def calculate_pet_correlations(datasets: Dict) -> pd.DataFrame:
    """
    Calculate correlations between PET modalities.

    Returns
    -------
    pd.DataFrame
        Correlation matrix.
    """
    # Get datasets
    bai_av45 = datasets.get('BAIPETNMRCAV45_10_23_20_13Feb2026', {}).get('df')
    ucb_tau = datasets.get('UCBERKELEY_TAU_6MM_13Feb2026', {}).get('df')
    bai_fdg = datasets.get('BAIPETNMRCFDG_12_11_20_13Feb2026', {}).get('df')

    if bai_av45 is None or ucb_tau is None or bai_fdg is None:
        return pd.DataFrame()

    # Merge datasets
    av45_data = bai_av45[['RID', 'VISCODE2', 'MCSUVRWM']].copy()
    tau_data = ucb_tau[['RID', 'VISCODE2', 'META_TEMPORAL_SUVR']].copy()
    fdg_data = bai_fdg[['RID', 'VISCODE2', 'SROI.AD']].copy()

    merged = av45_data.merge(tau_data, on=['RID', 'VISCODE2'], how='inner')
    merged = merged.merge(fdg_data, on=['RID', 'VISCODE2'], how='inner')

    # Calculate correlations
    corr_cols = ['MCSUVRWM', 'META_TEMPORAL_SUVR', 'SROI.AD']
    corr_data = merged[corr_cols].dropna()
    corr_data = corr_data[(corr_data >= 0).all(axis=1)]

    corr_matrix = corr_data.corr()
    corr_matrix.index = ['AV45', 'Tau', 'FDG']
    corr_matrix.columns = ['AV45', 'Tau', 'FDG']

    return corr_matrix


# =============================================================================
# MAIN EXECUTION
# =============================================================================

if __name__ == '__main__':
    # Example usage
    data_dir = Path('/mnt/okcomputer/upload')

    print("Loading PET data...")
    datasets = load_pet_data(data_dir)

    print("\nAnalyzing PET biomarkers...")
    results = analyze_pet_biomarkers(datasets)

    for modality, df in results.items():
        print(f"\n{modality.upper()}:")
        print(df.to_string(index=False))

    print("\nCalculating PET correlations...")
    corr = calculate_pet_correlations(datasets)
    print(corr.to_string())
