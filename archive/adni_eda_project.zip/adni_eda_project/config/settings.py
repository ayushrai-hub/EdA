"""
ADNI EDA Project Configuration Settings
=======================================
Centralized configuration for paths, constants, and parameters.
"""

from pathlib import Path

# =============================================================================
# PATH CONFIGURATION
# =============================================================================

# Base directories
PROJECT_ROOT = Path(__file__).parent.parent
DATA_DIR = Path('/mnt/okcomputer/upload')  # Adjust to your data location
OUTPUT_DIR = PROJECT_ROOT / 'output'

# Output subdirectories
REPORTS_DIR = OUTPUT_DIR / 'reports'
TABLES_DIR = OUTPUT_DIR / 'tables'
VISUALIZATIONS_DIR = OUTPUT_DIR / 'visualizations'

# Create directories if they don't exist
for dir_path in [REPORTS_DIR, TABLES_DIR, VISUALIZATIONS_DIR]:
    dir_path.mkdir(parents=True, exist_ok=True)

# =============================================================================
# DATA CONFIGURATION
# =============================================================================

# Sentinel values to treat as missing
SENTINEL_VALUES = [
    -4, -4.0, '-4',           # ADNI standard missing code
    -999, -999.0,             # Alternative missing code
    '', ' ',                  # Empty strings
    'NA', 'N/A', 'na', 'n/a', # Common NA strings
    'NULL', 'null',           # Database NULL
    'None', 'none',           # Python None
    'nan', 'NaN',             # NaN strings
]

# File categories for organization
FILE_CATEGORIES = {
    'biospecimen': [
        'UPENN_PLASMA_FUJIREBIO_QUANTERIX_13Feb2026.csv',
        'APOERES_13Feb2026.csv',
        'batemanlab_20190621_13Feb2026.csv',
        'batemanlab_20221118_13Feb2026.csv',
        'YASSINE_PLASMA_13Feb2026.csv',
        'YASSINE_CSF_13Feb2026.csv',
    ],
    'neuropsychological': [
        'ADAS_13Feb2026.csv',
        'CDR_13Feb2026.csv',
        'MOCA_13Feb2026.csv',
        'FAQ_13Feb2026.csv',
        'NPI_13Feb2026.csv',
        'ECOGPT_13Feb2026.csv',
        'ECOGSP_13Feb2026.csv',
        'GDSCALE_13Feb2026.csv',
        'IES_13Feb2026.csv',
        'WATC_13Feb2026.csv',
    ],
    'imaging_mri': [
        'ADNI_PICSLASHS_13Feb2026.csv',
        'BSI_13Feb2026.csv',
        'MRI3META_13Feb2026.csv',
        'MRIMPRANK_13Feb2026.csv',
        'MRIQC_13Feb2026.csv',
        'TBM_03_17_2022_13Feb2026.csv',
        'UASPMVBM_13Feb2026.csv',
        'UCSFASLFS_11_02_15_V2_13Feb2026.csv',
        'UCSFASLQC_13Feb2026.csv',
        'UCSFATRPHY_13Feb2026.csv',
        'UCSFFSL51Y1_08_01_16_13Feb2026.csv',
        'UCSFSNTVOL_13Feb2026.csv',
        'UPENNSPARE_MCI_08_12_16_13Feb2026.csv',
    ],
}

# Files to exclude (duplicates)
FILES_TO_EXCLUDE = [
    'APOERES_13Feb2026(1).csv', 'APOERES_13Feb2026(2).csv',
    'YASSINE_CSF_13Feb2026(1).csv', 'YASSINE_CSF_13Feb2026(2).csv',
    'YASSINE_PLASMA_13Feb2026(1).csv', 'YASSINE_PLASMA_13Feb2026(2).csv',
    'batemanlab_20190621_13Feb2026(1).csv',
    'batemanlab_20221118_13Feb2026(1).csv',
]

# =============================================================================
# ANALYSIS CONFIGURATION
# =============================================================================

# Outlier detection parameters
OUTLIER_IQR_MULTIPLIER = 1.5
OUTLIER_ZSCORE_THRESHOLD = 3.0

# Correlation analysis parameters
CORRELATION_METHODS = ['pearson', 'spearman']

# Missing data thresholds
MISSING_HIGH_THRESHOLD = 0.50  # 50% missing = sparse column
MISSING_MODERATE_THRESHOLD = 0.30  # 30% missing = moderate concern

# =============================================================================
# VISUALIZATION CONFIGURATION
# =============================================================================

# Figure settings
FIGURE_DPI = 150
FIGURE_FORMAT = 'png'
FIGURE_SIZE = (12, 8)

# Color scheme
COLORS = {
    'primary': '#4472C4',
    'secondary': '#ED7D31',
    'tertiary': '#A5A5A5',
    'success': '#70AD47',
    'warning': '#FFC000',
    'danger': '#C5504B',
    'info': '#5B9BD5',
}

# =============================================================================
# KEY COLUMN DEFINITIONS
# =============================================================================

# Identifier columns
ID_COLUMNS = ['RID', 'PTID', 'VISCODE', 'VISCODE2', 'PHASE']

# Date columns (for auto-detection)
DATE_COLUMN_PATTERNS = ['date', 'stamp', 'time', 'DATE', 'STAMP', 'TIME']

# Biomarker columns of interest
BIOMARKER_COLUMNS = {
    'pT217_F': 'p-tau217 (Fujirebio)',
    'AB42_F': 'Aβ42 (Fujirebio)',
    'AB40_F': 'Aβ40 (Fujirebio)',
    'AB42_AB40_F': 'Aβ42/40 Ratio (Fujirebio)',
    'NfL_Q': 'NfL (Quanterix)',
    'GFAP_Q': 'GFAP (Quanterix)',
    'NfL_F': 'NfL (Fujirebio)',
    'GFAP_F': 'GFAP (Fujirebio)',
}

# Cognitive assessment columns
COGNITIVE_COLUMNS = {
    'MOCA': 'MoCA Total Score',
    'TOTSCORE': 'ADAS-Cog Total Score',
    'TOTAL13': 'ADAS-Cog 13-Item Score',
    'CDRSB': 'CDR Sum of Boxes',
    'CDGLOBAL': 'CDR Global Score',
}

# Imaging columns of interest
IMAGING_COLUMNS = {
    'LEFTHIPPO': 'Left Hippocampal Volume',
    'RIGHTHIPPO': 'Right Hippocampal Volume',
    'LEFT_CA1_VOL': 'Left CA1 Volume',
    'LEFT_DG_VOL': 'Left Dentate Gyrus Volume',
    'RIGHT_CA1_VOL': 'Right CA1 Volume',
    'RIGHT_DG_VOL': 'Right Dentate Gyrus Volume',
}
