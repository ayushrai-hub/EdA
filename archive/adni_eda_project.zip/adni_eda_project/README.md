# ADNI Comprehensive Exploratory Data Analysis (EDA) Project

A research-grade exploratory data analysis pipeline for the Alzheimer's Disease Neuroimaging Initiative (ADNI) dataset.

## Overview

This project provides a comprehensive EDA framework for analyzing ADNI data across multiple domains:
- **Biospecimen/Biomarkers**: Blood-based biomarkers (p-tau217, Aβ42/40, NfL, GFAP)
- **Neuropsychological Assessments**: Cognitive tests (MoCA, ADAS-Cog, CDR)
- **Imaging (MRI)**: Structural MRI measurements (hippocampal volumes, atrophy measures)

## Features

- **Automated Data Loading**: Handles multiple CSV files with duplicate detection
- **Schema Analysis**: Identifies key identifiers (RID, PTID, VISCODE) and relationships
- **Statistical Analysis**: Descriptive statistics, outlier detection, distribution analysis
- **Longitudinal Analysis**: Visit patterns, temporal coverage, dropout rates
- **Multimodal Correlations**: Cross-domain correlation analysis
- **ML Readiness Assessment**: Feature variance, multicollinearity, target variable analysis
- **Publication-Quality Visualizations**: Automated figure generation

## Project Structure

```
adni_eda_project/
├── config/
│   └── settings.py              # Configuration and constants
├── src/
│   ├── data/
│   │   └── loader.py            # Data loading and preprocessing
│   ├── analysis/
│   │   ├── schema_analyzer.py   # Schema and relationship analysis
│   │   ├── statistical_analyzer.py  # Statistical EDA
│   │   ├── longitudinal_analyzer.py # Longitudinal patterns
│   │   └── ml_readiness.py      # ML readiness assessment
│   └── visualization/
│       └── plots.py             # Visualization generation
├── notebooks/
│   └── ADNI_EDA_Notebook.ipynb  # Interactive Jupyter notebook
├── output/                      # Generated outputs (created at runtime)
│   ├── reports/                 # Generated reports
│   ├── tables/                  # CSV data tables
│   └── visualizations/          # PNG figures
├── run_eda.py                   # Main command-line script
├── requirements.txt             # Python dependencies
└── README.md                    # This file
```

## Installation

1. Clone or download this project
2. Install dependencies:

```bash
pip install -r requirements.txt
```

## Usage

### Command Line

Run the complete EDA pipeline:

```bash
python run_eda.py --data-dir /path/to/adni/csv/files --output-dir ./output
```

Options:
- `--data-dir`: Directory containing ADNI CSV files (default: `/mnt/okcomputer/upload`)
- `--output-dir`: Directory for output files (default: `./output`)
- `--skip-viz`: Skip visualization generation

### Jupyter Notebook

For interactive exploration:

```bash
jupyter notebook notebooks/ADNI_EDA_Notebook.ipynb
```

### Python API

```python
from src.data.loader import load_and_preprocess_adni_data
from src.analysis.schema_analyzer import SchemaAnalyzer
from src.analysis.statistical_analyzer import StatisticalAnalyzer

# Load data
datasets, summary = load_and_preprocess_adni_data('/path/to/data')

# Schema analysis
schema_analyzer = SchemaAnalyzer(datasets)
schema_info = schema_analyzer.analyze_all()

# Statistical analysis
stat_analyzer = StatisticalAnalyzer(datasets)
bio_results = stat_analyzer.analyze_biomarkers()
```

## Key Findings

### Dataset Overview
- **29 unique datasets** across 3 domains
- **235,524 total records**
- **42,812 unique participants**
- **21 years** of temporal coverage (2005-2026)

### Critical Biomarker Correlations
| Biomarker | vs MoCA | vs ADAS | vs CDR-SB |
|-----------|---------|---------|-----------|
| p-tau217  | -0.50   | 0.51    | 0.50      |
| NfL       | -0.26   | 0.30    | 0.32      |
| GFAP      | -0.33   | 0.33    | 0.30      |

### ML Readiness
- ✓ **1,231 complete cases** (biomarker + cognitive)
- ✓ Good feature variance
- ⚠ 22.9% missing in NfL/GFAP (consider imputation)
- ⚠ MoCA/ADAS collinearity (r = -0.77)
- ⚠ Moderate class imbalance (3.37:1)

## Data Quality Notes

### High Missing Data (>40%)
- **WATC**: 73.3% (ADNI4-specific instrument)
- **NPI**: 69.7% (sparse neuropsychiatric inventory)
- **APOERES**: 46.5% (limited VISCODE coverage)

### Identifier Issues
- **MRIQC**: Missing RID/PTID - uses VISCODE2 only
- **UCSFASLQC**: Missing RID - uses PTID only

### Sentinel Values
The following are automatically treated as missing:
- Numeric: `-4`, `-999`
- String: `''`, `'NA'`, `'NULL'`, `'None'`

## Output Files

### Reports
- `ADNI_Comprehensive_EDA_Report.md` - Full markdown report

### Tables (CSV)
- `dataset_summary.csv` - Dataset overview
- `schema_analysis.csv` - Schema details
- `biomarker_statistics.csv` - Biomarker descriptive stats
- `biomarker_outliers.csv` - Outlier analysis
- `correlation_matrix.csv` - Multimodal correlations
- `visit_patterns.csv` - Longitudinal patterns
- `ml_feature_variance.csv` - ML feature analysis

### Visualizations (PNG)
- `01_dataset_overview.png` - Dataset overview by category
- `02_missing_data.png` - Missing data analysis
- `03_biomarker_distributions.png` - Biomarker distributions
- `04_correlation_heatmap.png` - Correlation heatmap
- `05_study_phases.png` - Study phase distribution
- `06_longitudinal_patterns.png` - Visit patterns
- `07_cdr_distribution.png` - CDR Global distribution

## Recommended ML Feature Set

### Input Features
- **Blood Biomarkers**: p-tau217, Aβ42/40 ratio, NfL, GFAP
- **Cognitive**: MoCA total score (or ADAS-Cog total)

### Target Variables
- **Primary**: CDR Global score (multiclass: 0, 0.5, 1, 2, 3)
- **Secondary**: Binary impairment (CDR > 0)
- **Tertiary**: MCI/Dementia (CDR ≥ 0.5)

### Derived Features (Recommended)
- p-tau217 / Aβ42 ratio
- Biomarker z-score composite
- Age × biomarker interactions (when demographics available)

## Citation

If you use this code for your research, please cite:

```
ADNI Comprehensive EDA Pipeline
Author: Senior Biomedical Data Scientist
Date: 2026-03-06
```

## License

This project is provided for research purposes. Please refer to ADNI data use agreements when using ADNI data.

## Contact

For questions or issues, please refer to the ADNI documentation or contact the data access team.

---

**Note**: This analysis is based on ADNI data provided by the Alzheimer's Disease Neuroimaging Initiative. All findings are for research purposes only and should not be used for clinical diagnosis without proper validation.
