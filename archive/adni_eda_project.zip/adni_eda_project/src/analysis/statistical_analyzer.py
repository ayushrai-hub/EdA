"""
ADNI Statistical Analyzer Module
================================
Performs statistical EDA including descriptive statistics, outlier detection,
and distribution analysis for biomarkers and cognitive assessments.
"""

import pandas as pd
import numpy as np
from scipy import stats
from typing import Dict, List, Optional, Tuple

from config.settings import (
    BIOMARKER_COLUMNS, COGNITIVE_COLUMNS, IMAGING_COLUMNS,
    OUTLIER_IQR_MULTIPLIER, OUTLIER_ZSCORE_THRESHOLD
)


class StatisticalAnalyzer:
    """
    Comprehensive statistical analysis for ADNI data.
    """
    
    def __init__(self, datasets: Dict[str, Dict]):
        """
        Initialize statistical analyzer.
        
        Parameters
        ----------
        datasets : Dict[str, Dict]
            Dictionary of loaded datasets.
        """
        self.datasets = datasets
        
    def descriptive_statistics(self, df: pd.DataFrame, columns: List[str],
                                filter_negative: bool = True) -> pd.DataFrame:
        """
        Calculate comprehensive descriptive statistics.
        
        Parameters
        ----------
        df : pd.DataFrame
            Input DataFrame.
        columns : List[str]
            Columns to analyze.
        filter_negative : bool
            Whether to filter out negative values (sentinel values).
            
        Returns
        -------
        pd.DataFrame
            Descriptive statistics table.
        """
        results = []
        
        for col in columns:
            if col not in df.columns:
                continue
                
            data = df[col].dropna()
            
            # Filter negative values if requested
            if filter_negative:
                data = data[data >= 0]
            
            if len(data) == 0:
                continue
            
            stats_dict = {
                'Variable': col,
                'N': len(data),
                'Mean': data.mean(),
                'Std': data.std(),
                'Min': data.min(),
                'Q1': data.quantile(0.25),
                'Median': data.median(),
                'Q3': data.quantile(0.75),
                'Max': data.max(),
                'IQR': data.quantile(0.75) - data.quantile(0.25),
                'Skewness': data.skew(),
                'Kurtosis': data.kurtosis(),
                'CV': data.std() / data.mean() if data.mean() != 0 else np.nan,
            }
            
            results.append(stats_dict)
        
        return pd.DataFrame(results)
    
    def detect_outliers_iqr(self, df: pd.DataFrame, columns: List[str],
                            multiplier: float = OUTLIER_IQR_MULTIPLIER) -> pd.DataFrame:
        """
        Detect outliers using the IQR method.
        
        Parameters
        ----------
        df : pd.DataFrame
            Input DataFrame.
        columns : List[str]
            Columns to analyze.
        multiplier : float
            IQR multiplier (default 1.5).
            
        Returns
        -------
        pd.DataFrame
            Outlier analysis results.
        """
        results = []
        
        for col in columns:
            if col not in df.columns:
                continue
                
            data = df[col].dropna()
            data = data[data >= 0]  # Filter sentinel values
            
            if len(data) == 0:
                continue
            
            Q1 = data.quantile(0.25)
            Q3 = data.quantile(0.75)
            IQR = Q3 - Q1
            
            lower_bound = Q1 - multiplier * IQR
            upper_bound = Q3 + multiplier * IQR
            
            outliers_low = (data < lower_bound).sum()
            outliers_high = (data > upper_bound).sum()
            total_outliers = outliers_low + outliers_high
            
            results.append({
                'Variable': col,
                'Lower_Bound': lower_bound,
                'Upper_Bound': upper_bound,
                'N_Low_Outliers': int(outliers_low),
                'N_High_Outliers': int(outliers_high),
                'Total_Outliers': int(total_outliers),
                'Outlier_Pct': (total_outliers / len(data)) * 100,
            })
        
        return pd.DataFrame(results)
    
    def detect_outliers_zscore(self, df: pd.DataFrame, columns: List[str],
                                threshold: float = OUTLIER_ZSCORE_THRESHOLD) -> pd.DataFrame:
        """
        Detect outliers using Z-score method.
        
        Parameters
        ----------
        df : pd.DataFrame
            Input DataFrame.
        columns : List[str]
            Columns to analyze.
        threshold : float
            Z-score threshold (default 3.0).
            
        Returns
        -------
        pd.DataFrame
            Z-score outlier results.
        """
        results = []
        
        for col in columns:
            if col not in df.columns:
                continue
                
            data = df[col].dropna()
            data = data[data >= 0]
            
            if len(data) < 3:
                continue
            
            z_scores = np.abs(stats.zscore(data))
            outlier_count = (z_scores > threshold).sum()
            
            results.append({
                'Variable': col,
                'Z_Threshold': threshold,
                'N_Outliers': int(outlier_count),
                'Outlier_Pct': (outlier_count / len(data)) * 100,
                'Max_Z_Score': z_scores.max(),
            })
        
        return pd.DataFrame(results)
    
    def analyze_biomarkers(self, dataset_name: str = 'UPENN_PLASMA_FUJIREBIO_QUANTERIX_13Feb2026') -> Dict:
        """
        Comprehensive analysis of biomarker data.
        
        Parameters
        ----------
        dataset_name : str
            Name of the biomarker dataset.
            
        Returns
        -------
        Dict
            Dictionary containing descriptive stats and outlier analysis.
        """
        if dataset_name not in self.datasets:
            raise ValueError(f"Dataset '{dataset_name}' not found")
        
        df = self.datasets[dataset_name]['df']
        
        # Get biomarker columns present in the dataset
        biomarker_cols = [col for col in BIOMARKER_COLUMNS.keys() if col in df.columns]
        
        results = {
            'dataset': dataset_name,
            'total_samples': len(df),
            'unique_participants': df['RID'].nunique() if 'RID' in df.columns else 0,
            'descriptive_stats': self.descriptive_statistics(df, biomarker_cols),
            'outliers_iqr': self.detect_outliers_iqr(df, biomarker_cols),
        }
        
        return results
    
    def analyze_cognitive_assessments(self) -> Dict:
        """
        Analyze all cognitive assessment datasets.
        
        Returns
        -------
        Dict
            Dictionary of cognitive assessment analyses.
        """
        cognitive_datasets = {
            'MOCA': ('MOCA_13Feb2026', ['MOCA']),
            'ADAS': ('ADAS_13Feb2026', ['TOTSCORE', 'TOTAL13']),
            'CDR': ('CDR_13Feb2026', ['CDRSB', 'CDGLOBAL']),
        }
        
        results = {}
        
        for name, (dataset_name, columns) in cognitive_datasets.items():
            if dataset_name not in self.datasets:
                continue
                
            df = self.datasets[dataset_name]['df']
            
            results[name] = {
                'total_assessments': len(df),
                'unique_participants': df['RID'].nunique() if 'RID' in df.columns else 0,
                'descriptive_stats': self.descriptive_statistics(df, columns),
            }
            
            # Add CDR global distribution if available
            if name == 'CDR' and 'CDGLOBAL' in df.columns:
                cdr_global = df['CDGLOBAL'].dropna()
                cdr_global = cdr_global[cdr_global >= 0]
                results[name]['cdr_distribution'] = cdr_global.value_counts().sort_index().to_dict()
        
        return results
    
    def analyze_imaging(self, dataset_name: str = 'UCSFSNTVOL_13Feb2026') -> Dict:
        """
        Analyze imaging biomarkers (hippocampal volumes).
        
        Parameters
        ----------
        dataset_name : str
            Name of the imaging dataset.
            
        Returns
        -------
        Dict
            Imaging analysis results.
        """
        if dataset_name not in self.datasets:
            raise ValueError(f"Dataset '{dataset_name}' not found")
        
        df = self.datasets[dataset_name]['df']
        
        # Get imaging columns present
        imaging_cols = [col for col in IMAGING_COLUMNS.keys() if col in df.columns]
        
        results = {
            'dataset': dataset_name,
            'total_scans': len(df),
            'unique_participants': df['RID'].nunique() if 'RID' in df.columns else 0,
            'descriptive_stats': self.descriptive_statistics(df, imaging_cols, filter_negative=True),
        }
        
        # Calculate total hippocampal volume if both sides available
        if 'LEFTHIPPO' in df.columns and 'RIGHTHIPPO' in df.columns:
            left = df['LEFTHIPPO'].dropna()
            right = df['RIGHTHIPPO'].dropna()
            left = left[left > 0]
            right = right[right > 0]
            
            # For paired data
            paired_data = df[['LEFTHIPPO', 'RIGHTHIPPO']].dropna()
            paired_data = paired_data[(paired_data > 0).all(axis=1)]
            
            if len(paired_data) > 0:
                total_vol = paired_data['LEFTHIPPO'] + paired_data['RIGHTHIPPO']
                results['total_hippocampal_volume'] = {
                    'N': len(total_vol),
                    'Mean': total_vol.mean(),
                    'Std': total_vol.std(),
                    'Min': total_vol.min(),
                    'Max': total_vol.max(),
                    'Median': total_vol.median(),
                }
        
        return results
    
    def calculate_correlation_matrix(self, df: pd.DataFrame, columns: List[str],
                                      method: str = 'pearson') -> pd.DataFrame:
        """
        Calculate correlation matrix for specified columns.
        
        Parameters
        ----------
        df : pd.DataFrame
            Input DataFrame.
        columns : List[str]
            Columns to include.
        method : str
            Correlation method ('pearson', 'spearman', 'kendall').
            
        Returns
        -------
        pd.DataFrame
            Correlation matrix.
        """
        # Filter to available columns
        available_cols = [col for col in columns if col in df.columns]
        
        if len(available_cols) < 2:
            return pd.DataFrame()
        
        # Get data and filter sentinel values
        data = df[available_cols].copy()
        for col in available_cols:
            data[col] = data[col].where(data[col] >= 0)
        
        return data.corr(method=method)
    
    def multimodal_correlation_analysis(self) -> Dict:
        """
        Perform multimodal correlation analysis across biomarkers, cognitive, and imaging.
        
        Returns
        -------
        Dict
            Correlation analysis results.
        """
        # Get datasets
        upenn = self.datasets.get('UPENN_PLASMA_FUJIREBIO_QUANTERIX_13Feb2026', {}).get('df')
        moca = self.datasets.get('MOCA_13Feb2026', {}).get('df')
        adas = self.datasets.get('ADAS_13Feb2026', {}).get('df')
        cdr = self.datasets.get('CDR_13Feb2026', {}).get('df')
        sntvol = self.datasets.get('UCSFSNTVOL_13Feb2026', {}).get('df')
        
        results = {}
        
        # Biomarker-Cognitive correlations
        if upenn is not None and moca is not None:
            # Merge on RID and VISCODE2
            bio_cols = ['RID', 'VISCODE2', 'pT217_F', 'AB42_AB40_F', 'NfL_Q', 'GFAP_Q']
            cog_cols = ['RID', 'VISCODE2', 'MOCA']
            
            bio_data = upenn[[col for col in bio_cols if col in upenn.columns]].copy()
            cog_data = moca[[col for col in cog_cols if col in moca.columns]].copy()
            
            if 'VISCODE2' in bio_data.columns and 'VISCODE2' in cog_data.columns:
                merged = bio_data.merge(cog_data, on=['RID', 'VISCODE2'], how='inner')
                
                corr_cols = ['pT217_F', 'AB42_AB40_F', 'NfL_Q', 'GFAP_Q', 'MOCA']
                corr_cols = [col for col in corr_cols if col in merged.columns]
                
                if len(corr_cols) >= 2:
                    results['biomarker_cognitive'] = {
                        'n_records': len(merged),
                        'n_participants': merged['RID'].nunique(),
                        'correlation_matrix': self.calculate_correlation_matrix(merged, corr_cols),
                    }
        
        # Biomarker-Imaging correlations
        if upenn is not None and sntvol is not None:
            # Use latest visit per participant
            bio_latest = upenn.groupby('RID').last().reset_index()
            img_latest = sntvol.groupby('RID').last().reset_index()
            
            merged = bio_latest.merge(img_latest, on='RID', how='inner')
            
            corr_cols = ['pT217_F', 'AB42_AB40_F', 'NfL_Q', 'GFAP_Q', 'LEFTHIPPO', 'RIGHTHIPPO']
            corr_cols = [col for col in corr_cols if col in merged.columns]
            
            if len(corr_cols) >= 2:
                results['biomarker_imaging'] = {
                    'n_participants': len(merged),
                    'correlation_matrix': self.calculate_correlation_matrix(merged, corr_cols),
                }
        
        return results


if __name__ == '__main__':
    # Example usage
    from src.data.loader import load_and_preprocess_adni_data
    
    datasets, _ = load_and_preprocess_adni_data()
    analyzer = StatisticalAnalyzer(datasets)
    
    # Analyze biomarkers
    bio_results = analyzer.analyze_biomarkers()
    print("\nBiomarker Descriptive Statistics:")
    print(bio_results['descriptive_stats'].to_string(index=False))
    
    # Analyze cognitive assessments
    cog_results = analyzer.analyze_cognitive_assessments()
    print("\n\nCognitive Assessment Results:")
    for name, result in cog_results.items():
        print(f"\n{name}:")
        print(result['descriptive_stats'].to_string(index=False))
