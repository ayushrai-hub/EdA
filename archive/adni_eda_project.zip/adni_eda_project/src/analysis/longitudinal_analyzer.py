"""
ADNI Longitudinal Analyzer Module
=================================
Analyzes visit patterns, temporal coverage, and longitudinal trajectories.
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional
from datetime import datetime


class LongitudinalAnalyzer:
    """
    Analysis of longitudinal patterns in ADNI data.
    """
    
    def __init__(self, datasets: Dict[str, Dict]):
        """
        Initialize longitudinal analyzer.
        
        Parameters
        ----------
        datasets : Dict[str, Dict]
            Dictionary of loaded datasets.
        """
        self.datasets = datasets
    
    def analyze_visit_patterns(self, dataset_name: str) -> Dict:
        """
        Analyze visit patterns for a single dataset.
        
        Parameters
        ----------
        dataset_name : str
            Name of the dataset.
            
        Returns
        -------
        Dict
            Visit pattern analysis results.
        """
        if dataset_name not in self.datasets:
            raise ValueError(f"Dataset '{dataset_name}' not found")
        
        df = self.datasets[dataset_name]['df']
        
        if 'RID' not in df.columns:
            return {'error': 'No RID column found'}
        
        # Visits per participant
        visits_per_participant = df.groupby('RID').size()
        
        results = {
            'total_participants': df['RID'].nunique(),
            'total_visits': len(df),
            'mean_visits_per_participant': visits_per_participant.mean(),
            'median_visits_per_participant': visits_per_participant.median(),
            'max_visits': visits_per_participant.max(),
            'participants_with_1_visit': int((visits_per_participant == 1).sum()),
            'participants_with_2plus_visits': int((visits_per_participant >= 2).sum()),
            'participants_with_3plus_visits': int((visits_per_participant >= 3).sum()),
            'pct_2plus_visits': (visits_per_participant >= 2).mean() * 100,
        }
        
        # Visit code distribution
        if 'VISCODE' in df.columns:
            results['viscode_distribution'] = df['VISCODE'].value_counts().head(15).to_dict()
        
        if 'VISCODE2' in df.columns:
            results['viscode2_distribution'] = df['VISCODE2'].value_counts().head(15).to_dict()
        
        # Date range
        date_cols = self.datasets[dataset_name].get('date_columns', [])
        for col in date_cols:
            if col in df.columns:
                dates = df[col].dropna()
                if len(dates) > 0:
                    results['date_column'] = col
                    results['date_range'] = {
                        'min': dates.min(),
                        'max': dates.max(),
                    }
                    if hasattr(dates.max() - dates.min(), 'days'):
                        results['date_span_days'] = (dates.max() - dates.min()).days
                        results['date_span_years'] = (dates.max() - dates.min()).days / 365.25
                    break
        
        return results
    
    def analyze_all_datasets(self) -> Dict[str, Dict]:
        """
        Analyze visit patterns for all datasets with RID.
        
        Returns
        -------
        Dict[str, Dict]
            Dictionary of visit pattern analyses.
        """
        results = {}
        
        for name, data in self.datasets.items():
            df = data['df']
            if 'RID' in df.columns:
                try:
                    results[name] = self.analyze_visit_patterns(name)
                except Exception as e:
                    results[name] = {'error': str(e)}
        
        return results
    
    def get_study_phase_distribution(self) -> pd.DataFrame:
        """
        Get study phase distribution across all datasets.
        
        Returns
        -------
        pd.DataFrame
            Phase distribution table.
        """
        phase_data = []
        
        for name, data in self.datasets.items():
            df = data['df']
            if 'PHASE' in df.columns:
                phase_counts = df['PHASE'].value_counts()
                for phase, count in phase_counts.items():
                    phase_data.append({
                        'Dataset': name,
                        'Phase': phase,
                        'Count': count,
                    })
        
        if not phase_data:
            return pd.DataFrame()
        
        phase_df = pd.DataFrame(phase_data)
        phase_summary = phase_df.groupby('Phase')['Count'].sum().sort_values(ascending=False)
        
        return phase_summary.reset_index()
    
    def calculate_visit_intervals(self, dataset_name: str) -> pd.DataFrame:
        """
        Calculate intervals between visits for each participant.
        
        Parameters
        ----------
        dataset_name : str
            Name of the dataset.
            
        Returns
        -------
        pd.DataFrame
            Visit interval statistics.
        """
        if dataset_name not in self.datasets:
            raise ValueError(f"Dataset '{dataset_name}' not found")
        
        df = self.datasets[dataset_name]['df']
        
        # Find date column
        date_col = None
        for col in ['EXAMDATE', 'VISDATE', 'USERDATE']:
            if col in df.columns:
                date_col = col
                break
        
        if date_col is None:
            return pd.DataFrame()
        
        # Calculate intervals per participant
        intervals = []
        
        for rid, group in df.groupby('RID'):
            if len(group) < 2:
                continue
            
            dates = group[date_col].dropna().sort_values()
            if len(dates) < 2:
                continue
            
            for i in range(1, len(dates)):
                interval = (dates.iloc[i] - dates.iloc[i-1]).days
                intervals.append({
                    'RID': rid,
                    'Interval_Days': interval,
                    'Interval_Months': interval / 30.44,
                })
        
        if not intervals:
            return pd.DataFrame()
        
        intervals_df = pd.DataFrame(intervals)
        
        return intervals_df
    
    def analyze_temporal_coverage(self) -> pd.DataFrame:
        """
        Analyze temporal coverage across all datasets.
        
        Returns
        -------
        pd.DataFrame
            Temporal coverage summary.
        """
        coverage_data = []
        
        for name, data in self.datasets.items():
            df = data['df']
            date_cols = data.get('date_columns', [])
            
            for col in date_cols:
                if col in df.columns:
                    dates = df[col].dropna()
                    if len(dates) > 0:
                        coverage_data.append({
                            'Dataset': name,
                            'Date_Column': col,
                            'Min_Date': dates.min(),
                            'Max_Date': dates.max(),
                            'Span_Days': (dates.max() - dates.min()).days if hasattr(dates.max() - dates.min(), 'days') else None,
                            'Span_Years': (dates.max() - dates.min()).days / 365.25 if hasattr(dates.max() - dates.min(), 'days') else None,
                        })
                        break  # Only use first valid date column per dataset
        
        return pd.DataFrame(coverage_data)
    
    def get_visit_summary_table(self) -> pd.DataFrame:
        """
        Get summary table of visit patterns for key datasets.
        
        Returns
        -------
        pd.DataFrame
            Visit summary table.
        """
        key_datasets = [
            'UPENN_PLASMA_FUJIREBIO_QUANTERIX_13Feb2026',
            'MOCA_13Feb2026',
            'CDR_13Feb2026',
            'ADAS_13Feb2026',
        ]
        
        summaries = []
        
        for name in key_datasets:
            if name in self.datasets:
                analysis = self.analyze_visit_patterns(name)
                if 'error' not in analysis:
                    summaries.append({
                        'Dataset': name,
                        'Participants': analysis['total_participants'],
                        'Total_Visits': analysis['total_visits'],
                        'Mean_Visits': round(analysis['mean_visits_per_participant'], 2),
                        'Max_Visits': analysis['max_visits'],
                        'Pct_2Plus_Visits': round(analysis['pct_2plus_visits'], 1),
                    })
        
        return pd.DataFrame(summaries)


if __name__ == '__main__':
    # Example usage
    from src.data.loader import load_and_preprocess_adni_data
    
    datasets, _ = load_and_preprocess_adni_data()
    analyzer = LongitudinalAnalyzer(datasets)
    
    # Analyze key datasets
    print("Visit Pattern Analysis:")
    print("=" * 80)
    
    for name in ['UPENN_PLASMA_FUJIREBIO_QUANTERIX_13Feb2026', 'MOCA_13Feb2026', 'CDR_13Feb2026']:
        if name in datasets:
            result = analyzer.analyze_visit_patterns(name)
            print(f"\n{name}:")
            print(f"  Participants: {result['total_participants']:,}")
            print(f"  Mean visits: {result['mean_visits_per_participant']:.2f}")
            print(f"  % with 2+ visits: {result['pct_2plus_visits']:.1f}%")
